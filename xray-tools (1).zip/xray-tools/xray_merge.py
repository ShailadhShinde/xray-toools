#!/usr/bin/env python3
"""
xray_merge.py - several compose files into ONE: the whole system in one compose file, one folder, one network.
Stdlib only, Python 3.8+, Docker with compose on the machine. Your compose files are only read, never changed.

    python xray_merge.py --name suite --out D:\\hosting\\system ^
        runs\\detector\\plan\\compose.combined.yml runs\\hub\\plan\\compose.combined.yml ^
        runs\\worker\\plan\\compose.combined.yml D:\\dashboard\\docker\\compose.yml --rename web=dashboard
    ... --db mysql      + a MySQL of the system's own (a container), the programs' database settings pointed to it.
                        Needed before clients: each client then gets its own database. --db postgres: a PostgreSQL.
                        On this PC it is reachable for Workbench / pgAdmin at 127.0.0.1:3307 (5433): --db-port

It reads each file as docker compose does (docker compose config, with the .env next to it) and writes into OUT:
  compose.yml   every service of every file on ONE network - the network you added by hand is not needed any more.
                A program that others call gets a healthcheck; the callers wait for it (depends_on).
  .env          what compose fills in: the images' versions (a new version = one line), the passwords
  NAME.env      each service's own settings (from its env_file); the addresses of the other services are their
                service names now (http://host.docker.internal:5014/check -> http://hub:5014/check)
  data/         the folders the programs write to (before: next to each compose file)
  merge.txt     everything it changed, what it left alone, the next commands
Then:   cd OUT    docker compose config -q    docker compose up -d --wait    docker compose ps
ONE_SYSTEM_WALKTHROUGH.md shows every step with its output; xray_clients.py makes the clients' copies of OUT.
"""
import argparse
import datetime
import json
import os
import re
import secrets
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from xray_clients import run, die, to_yaml, KEY_ORDER, SECRET_KEY  # noqa: E402  (the same YAML writer)

VERSION = "0.2.0"
REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)((?::?[-?+])[^}]*)?\}")
LOCAL = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "host.docker.internal", "gateway.docker.internal"}
IPV4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
ADDR = re.compile(r"(?P<pre>(?:[a-z][a-z0-9+.-]*://)?(?:[^\s/@:;=]+(?::[^\s/@;]*)?@)?)"
                  r"(?P<host>\d{1,3}(?:\.\d{1,3}){3}|[A-Za-z][A-Za-z0-9_.-]*)"
                  r":(?P<port>\d{2,5})(?![\d.])", re.I)
URL_DB = re.compile(r"^[a-z][a-z0-9+.-]*://(?P<user>[^:@/\s]+)(?::(?P<pw>[^@/\s]*))?@[^/\s]+/(?P<db>[^?\s]*)", re.I)
URL_CRED = re.compile(r"(://[^\s/@:;]+:)([^\s/@;]+)(@)")
CS_HOST = re.compile(r"(?i)(?<![A-Za-z])(server|host|data source|address|addr)\s*=\s*([^;]+)")
CS_PORT = re.compile(r"(?i)(?<![A-Za-z])(port)\s*=\s*(\d+)")
CS_USER = re.compile(r"(?i)(?<![A-Za-z])(uid|user id|user|username)\s*=\s*([^;]*)")
CS_PASS = re.compile(r"(?i)(?<![A-Za-z])(pwd|password)\s*=\s*([^;]*)")
CS_DB = re.compile(r"(?i)(?<![A-Za-z])(database|initial catalog)\s*=\s*([^;]*)")
DBW = r"(?:DB|DATABASE|MYSQL|SQL|MARIADB|PG|PGSQL|POSTGRES|POSTGRESQL)"
DB_HOST_VAR = re.compile(rf"(?i)(^|_){DBW}_?(HOST|HOSTNAME|SERVER|ADDR|ADDRESS|IP)$")
DB_PORT_VAR = re.compile(rf"(?i)(^|_){DBW}_?PORT$")
DB_PASS_VAR = re.compile(rf"(?i)(^|_){DBW}_?(PASSWORD|PASSWD|PASS|PWD)$")
DB_USER_VAR = re.compile(rf"(?i)(^|_){DBW}_?(USER|USERNAME|UID|LOGIN)$")
DB_NAME_VAR = re.compile(rf"(?i)(^|_){DBW}_?(NAME|SCHEMA)$|^(DB|DATABASE|MYSQL_DATABASE|POSTGRES_DB|PGDATABASE)$")
DB_PORTS = {3306: "MySQL", 5432: "PostgreSQL", 1433: "SQL Server", 1521: "Oracle", 27017: "MongoDB", 6379: "Redis"}
DB_KINDS = {             # --db: the database the system gets; "publish" = the port Workbench / pgAdmin use on this PC
    "mysql": {"label": "MySQL", "port": 3306, "publish": 3307, "image": "mysql", "version": "8.4",
              "var": "MYSQL_VERSION", "super": "root", "tool": "MySQL Workbench"},
    "postgres": {"label": "PostgreSQL", "port": 5432, "publish": 5433, "image": "postgres", "version": "17",
                 "var": "POSTGRES_VERSION", "super": "postgres", "tool": "pgAdmin or DBeaver"},
}
ENV_LINE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$")


def slug(s, upper=False):
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")
    return s.upper() if upper else s.lower()


def mask(key, val):
    """a value for the report: its password parts as ***"""
    if val is None:
        return ""
    if SECRET_KEY.search(key or "") or DB_PASS_VAR.search(key or ""):
        return "***"
    val = CS_PASS.sub(lambda m: m.group(1) + "=***", val)
    return URL_CRED.sub(lambda m: m.group(1) + "***" + m.group(3), val)


# ------------------------------------------------------------------------------------------------ env files
def env_value(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
        return v[1:-1]
    return v.split(" #", 1)[0].rstrip()


def read_lines(path):
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as fh:
            return fh.read().splitlines()
    except OSError:
        return []


def parse_env(path):
    """{name: value} of an env file, as compose reads it"""
    vals = {}
    for line in read_lines(path):
        m = ENV_LINE.match(line)
        if m and not line.lstrip().startswith("#"):
            vals[m.group(1)] = env_value(m.group(2))
    return vals


def env_line(name, value, like=None):
    """NAME=value, quoted the way the line it replaces was, or in single quotes when the value needs it"""
    q = None
    if like:
        m = re.match(r"^\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_.-]*\s*=\s*(['\"])", like)
        q = m.group(1) if m else None
    if q is None and re.search(r"[\s#'\";]", value or ""):
        q = "'" if "'" not in value else '"'
    return f"{name}={q}{value}{q}" if q else f"{name}={value}"


# ------------------------------------------------------------------------------------------------ compose
def load(path):
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        die(f"{path}: no such file")
    d = os.path.dirname(path)
    r = run(["docker", "compose", "-f", path, "config", "--format", "json", "--no-interpolate"], cwd=d, check=False)
    if r.returncode != 0:
        die(f"docker compose cannot read {path}:\n" + (r.stderr or r.stdout).strip())
    return {"path": path, "dir": d, "doc": json.loads(r.stdout), "env": parse_env(os.path.join(d, ".env"))}


def walk_strings(obj, fn):
    if isinstance(obj, dict):
        return {k: walk_strings(v, fn) for k, v in obj.items()}
    if isinstance(obj, list):
        return [walk_strings(v, fn) for v in obj]
    return fn(obj) if isinstance(obj, str) else obj


def refs_in(obj):
    out = set()

    def grab(s):
        out.update(m.group(1) for m in REF.finditer(s))
        return s
    walk_strings(obj, grab)
    return out


def resolve(text, env):
    """${NAME:-default} / ${NAME} with the values of a .env (enough for a folder's path)"""
    def sub(m):
        v, op = env.get(m.group(1)), m.group(2) or ""
        if op[:2] == ":-":
            return v if v else op[2:]
        if op[:1] == "-":
            return v if v is not None else op[1:]
        return v or ""
    return REF.sub(sub, text)


def same_name(name, out):
    """another folder that runs a compose project of this name would share its containers, network and volumes"""
    r = run(["docker", "compose", "ls", "-a", "--format", "json"], check=False)
    try:
        projects = json.loads(r.stdout or "[]")
    except ValueError:
        projects = []
    mine = os.path.normcase(os.path.join(out, "compose.yml"))
    for p in projects or []:
        files = [os.path.normcase(f.strip()) for f in (p.get("ConfigFiles") or "").split(",") if f.strip()]
        if p.get("Name") == name and files and mine not in files:
            die(f"a compose project named {name} runs already, from {', '.join(files)}. Two folders with one name share "
                f"their containers and their database volume: give this one another name (--name {name}2 ...), or "
                f"stop that one for good first (docker compose down in its folder)")
    r = run(["docker", "volume", "ls", "-q", "--filter", f"label=com.docker.compose.project={name}"], check=False)
    return [v for v in (r.stdout or "").split() if v]


def main(argv=None):
    for _s in (sys.stdout, sys.stderr):
        if hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="several compose files into ONE: the whole system on one network")
    ap.add_argument("files", nargs="+", help="the compose files: each program's compose.combined.yml, the dashboard's...")
    ap.add_argument("--out", required=True, help="the system's folder: compose.yml, .env, NAME.env, data/ go there")
    ap.add_argument("--name", default="system", help="the compose project's name: containers NAME-detector-1 ...")
    ap.add_argument("--rename", action="append", default=[], metavar="OLD=NEW",
                    help="a service's new name, e.g. web=dashboard (the others then reach it by that name); "
                         "PROJECT/OLD=NEW for the service of one file only, e.g. dashboard/web=dashboard")
    ap.add_argument("--db", choices=tuple(DB_KINDS), help="a database of the system's own (MySQL or PostgreSQL); the "
                    "programs' database settings are pointed to it (each client then gets its own database)")
    ap.add_argument("--db-port", type=int, metavar="PORT", help="the port of this PC that MySQL Workbench / pgAdmin use "
                    "to open the database: 127.0.0.1:PORT (default 3307 for mysql, 5433 for postgres; 0: none)")
    ap.add_argument("--force", action="store_true", help="write into an OUT that has a compose.yml already "
                    "(its compose.yml, .env and NAME.env files are written again)")
    a = ap.parse_args(argv)

    name = slug(a.name).replace("_", "-")
    out = os.path.abspath(a.out)
    if os.path.isfile(os.path.join(out, "compose.yml")) and not a.force:
        die(f"{out} has a compose.yml already: give another --out, or --force to write it again (the changes you made "
            "in its compose.yml, .env and NAME.env files are then gone)")
    renames, used_renames = {}, set()                  # "web" (in every file) or "dashboard/web" (in project dashboard)
    for r in a.rename:
        if "=" not in r:
            die(f"--rename {r}: write OLD=NEW, e.g. web=dashboard (or PROJECT/OLD=NEW for one file: dashboard/web=dashboard)")
        o, n = r.split("=", 1)
        renames[o.strip()] = slug(n).replace("_", "-")
    srcs = [load(f) for f in a.files]
    old_vols = same_name(name, out)
    os.makedirs(out, exist_ok=True)

    def new_name(proj, old):
        for k in (f"{proj}/{old}", old):
            if k in renames:
                used_renames.add(k)
                return renames[k]
        return old

    # ---- the services, their old names (others may still call them by those)
    services, origin, alias, twice = {}, {}, {}, set()
    for s in srcs:
        proj = s["doc"].get("name") or os.path.basename(s["dir"])
        s["proj"] = proj
        for old, svc in (s["doc"].get("services") or {}).items():
            new = new_name(proj, old)
            if new in services:
                other = origin[new][0]
                die(f"two files have a service called {new}: {other['path']} (project {other['proj']}) and {s['path']} "
                    f"(project {proj}). Give one of them another name: --rename {proj}/{old}=OTHER-NAME")
            services[new], origin[new] = svc, (s, old)
            for x in (old, svc.get("container_name"), f"{proj}-{old}-1", f"{proj}_{old}_1"):
                if x and x != new:
                    if x in alias and alias[x] != new:
                        twice.add(x)                   # two services were called x: an address x:port is not clear
                    alias[x] = new
        for old in (s["doc"].get("services") or {}):           # depends_on inside one file: its renamed services
            svc = services[new_name(proj, old)]
            if isinstance(svc.get("depends_on"), dict):
                svc["depends_on"] = {new_name(proj, k): v for k, v in svc["depends_on"].items()}
    for x in twice:
        alias.pop(x, None)
    unused = [o for o in renames if o not in used_renames]
    if unused:
        die(f"--rename {', '.join(unused)}: no such service in the files (they have: "
            + ", ".join(f"{origin[n][0]['proj']}/{origin[n][1]}" for n in services) + ")")
    if a.db and "db" in services:
        die(f"--db {a.db}: a service is called db already - leave --db out, or rename it: --rename db=OTHER")

    # ---- the ports each service listens on: inside its container (target), on the PC (published)
    listen = {}
    for n, svc in services.items():
        t, p = set(), {}
        for pt in svc.get("ports") or []:
            if isinstance(pt, dict) and pt.get("target"):
                t.add(int(pt["target"]))
                try:
                    p[int(str(pt.get("published") or "").split("-")[0])] = int(pt["target"])
                except ValueError:
                    pass
        listen[n] = (t, p)

    def server_for(host, port):
        """(service, its port inside) that answers host:port - or None. Only this PC's addresses and the services'
        own names count: a camera or a server elsewhere stays as it is"""
        port, h = int(port), host.lower()
        svc = host if host in services else alias.get(host)
        if svc:
            t, p = listen[svc]
            return svc, (port if port in t else p.get(port, port))
        if "." in h and h not in LOCAL and not IPV4.match(h):
            return None                                        # a name like api.example.com: somewhere else
        hits = [(n, p[port]) for n, (t, p) in listen.items() if port in p]
        if len(hits) == 1:                                     # this PC's address + a port a service published
            return hits[0]
        if h in LOCAL:                                         # 127.0.0.1:5011 from the runs on the PC itself
            hits = [(n, port) for n, (t, p) in listen.items() if port in t]
            return hits[0] if len(hits) == 1 else None
        return None

    def addr_like(host):
        """this PC, an IP address, or a machine's name"""
        h = host.lower()
        return h in LOCAL or bool(IPV4.match(h)) or "." not in h

    def noted(host):
        """worth a line under OUTSIDE THIS SYSTEM: this PC or an IP (a bare word with a colon may be anything)"""
        h = host.lower()
        return h in LOCAL or bool(IPV4.match(h))

    # ---- .env: the ${NAMES} the files use, one value each (a name with another value in another file: renamed)
    menv, mraw, var_map = {}, {}, {}
    notes = []
    for s in srcs:
        raw = {}
        for line in read_lines(os.path.join(s["dir"], ".env")):
            m = ENV_LINE.match(line)
            if m and not line.lstrip().startswith("#"):
                raw[m.group(1)] = line
        mine = [n for n, (src, _o) in origin.items() if src is s]
        used = set()
        for n in mine:
            used |= refs_in(services[n])
        prefix = slug(mine[0] if mine else os.path.basename(s["dir"]), upper=True)
        for v in sorted(used):
            val, nv = s["env"].get(v), v
            if v in menv and val is not None and menv[v] != val:
                nv = f"{prefix}_{v}"
                notes.append(f"  .env {v}: another value in {s['path']} - that file's services use {nv} now")
            var_map[(s["path"], v)] = nv
            if val is not None and nv not in menv:
                menv[nv], mraw[nv] = val, raw.get(v)
    for n in services:
        s = origin[n][0]
        services[n] = walk_strings(services[n], lambda t, s=s: REF.sub(
            lambda m: "${" + var_map.get((s["path"], m.group(1)), m.group(1)) + (m.group(2) or "") + "}", t))

    # ---- folders: what a program writes (next to its compose file) -> data/SERVICE-NAME; the rest stays where it is
    made, kept, folder_vars = [], [], {}
    for n, svc in services.items():
        s = origin[n][0]
        senv = {var_map.get((s["path"], k), k): v for k, v in s["env"].items()}
        back = {var_map.get((s["path"], k), k): k for k in s["env"]}
        vols = []
        for v in svc.pop("volumes", None) or []:
            if not isinstance(v, dict) or v.get("type") not in ("bind", "volume") or not v.get("source"):
                vols.append(v)
                continue
            src, tgt, ro = str(v["source"]), v.get("target"), bool(v.get("read_only"))
            suffix = ":ro" if ro else ""
            raw = resolve(src, senv)
            if not re.match(r"^(\.{1,2}([\\/]|$)|/|[A-Za-z]:[\\/]|~)", raw):          # a named volume (dbdata ...)
                vols.append(f"{src}:{tgt}{suffix}")
                continue
            full = os.path.normpath(os.path.join(s["dir"], os.path.expanduser(raw)))
            nf, nd = os.path.normcase(full), os.path.normcase(s["dir"])
            if ro or not (nf == nd or nf.startswith(nd + os.sep)):
                where = full                                   # read only (models ...) or a folder of yours: as it was
                if ro and (nf == nd or nf.startswith(nd + os.sep)):
                    kept.append(f"  {n}: {full} (read only) - used where it is")
            else:                                              # written to, next to the old compose file: data/
                base = re.sub(r"[^A-Za-z0-9_.-]", "_", os.path.basename(full.rstrip("\\/")) or "folder")
                where = f"./data/{n}-{base}"
                os.makedirs(os.path.join(out, where), exist_ok=True)
                if (where, full, n) not in made:
                    made.append((where, full, n))
            vols.append(f"{where}:{tgt}{suffix}")
            for m in REF.finditer(src):                        # OUTPUT_DIR=./output: the folder is in compose.yml now
                folder_vars.setdefault(n, {}).setdefault(back.get(m.group(1), m.group(1)), where)
        if vols:
            svc["volumes"] = vols

    # ---- each service's settings: its env_file copied to NAME.env, the other services' addresses -> their names
    envfiles, edges, changes, outside = {}, {}, [], []
    db = "db" if a.db else None
    kind = DB_KINDS.get(a.db) or {}
    dbport = kind.get("port")

    def edge(n, to):
        if to != n:
            edges.setdefault(n, set()).add(to)

    def fix_value(n, key, val):
        if not isinstance(val, str) or not val:
            return val
        csh = CS_HOST.search(val)
        if csh and (CS_PORT.search(val) or CS_DB.search(val) or CS_USER.search(val)):     # a connection string
            host = csh.group(2).strip()
            pm = CS_PORT.search(val)
            port = int(pm.group(2)) if pm else (dbport or 3306)
            if db and port == dbport and addr_like(host) and not server_for(host, port):
                edge(n, "db")
                return val[:csh.start(2)] + "db" + val[csh.end(2):]
            hit = server_for(host, port)
            if hit:
                edge(n, hit[0])
                new = val[:csh.start(2)] + hit[0] + val[csh.end(2):]
                return CS_PORT.sub(lambda m: m.group(1) + "=" + str(hit[1]), new) if pm else new
            if noted(host):
                outside.append(f"  {n}  {key}: {host}:{port}" + (f" - a {DB_PORTS[port]} outside this system" +
                               (f" (--db {'mysql' if port == 3306 else 'postgres'}: the system's own)"
                                if port in (3306, 5432) else "") if port in DB_PORTS else
                               " - outside this system"))
            return val
        if DB_HOST_VAR.search(key) and ":" not in val and "/" not in val:
            h = val.strip()
            if h in services or h in alias:
                edge(n, h if h in services else alias[h])
                return alias.get(h, h)
            if addr_like(h):
                if db:
                    edge(n, "db")
                    return "db"
                outside.append(f"  {n}  {key}: {h} - a database outside this system (--db mysql or --db postgres: "
                               "the system's own)")
            return val
        if db and DB_PORT_VAR.search(key) and val.strip().isdigit() and val.strip() != str(dbport) \
                and int(val.strip()) in DB_PORTS and not any(int(val.strip()) in p for _t, p in listen.values()):
            return str(dbport)

        def sub(m):
            host, port = m.group("host"), int(m.group("port"))
            hit = server_for(host, port)
            if hit:
                edge(n, hit[0])
                return m.group("pre") + f"{hit[0]}:{hit[1]}"
            if db and port == dbport and addr_like(host):
                edge(n, "db")
                return m.group("pre") + f"db:{dbport}"
            if noted(host):
                outside.append(f"  {n}  {key}: {host}:{port} - " + (f"a {DB_PORTS[port]} outside this system"
                               if port in DB_PORTS else "outside this system (no service here listens on it)"))
            return m.group(0)
        return ADDR.sub(sub, val)

    for n, svc in services.items():
        efs = []
        for i, ef in enumerate(svc.pop("env_file", None) or []):
            p = ef["path"] if isinstance(ef, dict) else ef
            if not os.path.isfile(p):
                if not (isinstance(ef, dict) and ef.get("required") is False):
                    notes.append(f"  {n}: its env_file {p} is missing - nothing copied")
                continue
            dst = f"{n}.env" if i == 0 else f"{n}-{i + 1}.env"
            lines = [f"# {n}'s settings - copied by xray_merge.py from {p} on {datetime.date.today()}.",
                     "# The other services of the system: by their service names. Never commit this file."]
            done = set()
            for line in read_lines(p):
                if re.match(r"^#\s*\.env for .*copy to \.env", line):
                    continue                                   # the old file's own header: not true here
                m = ENV_LINE.match(line)
                if m and not line.lstrip().startswith("#"):
                    k, v = m.group(1), env_value(m.group(2))
                    if k in folder_vars.get(n, {}):            # a folder of this PC for the old compose file
                        if k not in done:
                            lines.append(f"# {k}: not needed here - the folder is in compose.yml now ({folder_vars[n][k]})")
                            done.add(k)
                        continue
                    nv = fix_value(n, k, v)
                    if nv != v:
                        changes.append(f"  {n:<10} {k}: {mask(k, v)}  ->  {mask(k, nv)}   ({dst})")
                        lines.append(f"# xray_merge.py: was {mask(k, v)}")
                        line = env_line(k, nv, line)
                lines.append(line)
            envfiles[dst] = {"lines": lines, "src": p, "service": n}
            efs.append("./" + dst)
        if efs:
            svc["env_file"] = efs
        env = svc.get("environment") or {}
        if isinstance(env, list):
            env = dict(x.split("=", 1) if "=" in x else (x, None) for x in env)
        for k, v in list(env.items()):
            if not isinstance(v, str):
                continue
            pure = REF.fullmatch(v.strip())
            if pure and pure.group(1) in menv:                 # ${NAME}: the value is in .env - changed there
                var = pure.group(1)
                nv = fix_value(n, k, menv[var])
                if nv != menv[var]:
                    changes.append(f"  {n:<10} {k}: {mask(k, menv[var])}  ->  {mask(k, nv)}   (.env {var})")
                    menv[var], mraw[var] = nv, None
                continue
            nv = fix_value(n, k, v)
            if nv != v:
                changes.append(f"  {n:<10} {k}: {mask(k, v)}  ->  {mask(k, nv)}   (compose.yml)")
                env[k] = nv
        if env:
            svc["environment"] = env

    # ---- --db: the system's own database. Its passwords: new, once, in .env; the programs get them from there
    dbinfo = []
    if db:
        users, names, old_pw = [], [], {}

        def note_db(user, pw, dbname):
            if user and user not in users:
                users.append(user)
            if dbname and dbname not in names:
                names.append(dbname)
            if pw:
                old_pw[pw] = user or ""

        def scan(v):
            if not isinstance(v, str):
                return
            if CS_HOST.search(v) and re.search(r"(?i)(server|host|data source|address|addr)\s*=\s*db\s*(;|$)", v):
                um, pm, dm = CS_USER.search(v), CS_PASS.search(v), CS_DB.search(v)
                note_db(um and um.group(2).strip(), pm and pm.group(2).strip(), dm and dm.group(2).strip())
            m = URL_DB.match(v)
            if m and "@db:" in v:
                note_db(m.group("user"), m.group("pw"), m.group("db"))

        def settings_of(n):
            per = {}
            for f, e in envfiles.items():
                if e["service"] != n:
                    continue
                for line in e["lines"]:
                    m = ENV_LINE.match(line)
                    if m and not line.lstrip().startswith("#"):
                        per[m.group(1)] = env_value(m.group(2))
            for k, v in (services[n].get("environment") or {}).items():
                pure = REF.fullmatch(v.strip()) if isinstance(v, str) else None
                per[k] = menv.get(pure.group(1), v) if pure else v
            return per
        for n in services:
            if "db" not in edges.get(n, ()):
                continue
            per = settings_of(n)
            user = next((v for k, v in per.items() if DB_USER_VAR.search(k) and v), None)
            dbname = next((v for k, v in per.items() if DB_NAME_VAR.search(k) and v), None)
            pw = next((v for k, v in per.items() if DB_PASS_VAR.search(k) and v), None)
            if user or pw or dbname:
                note_db(user, pw, dbname)
            for v in per.values():
                scan(v)
        mysql = a.db == "mysql"
        non_root = [u for u in users if u.lower() != kind["super"]]
        db_user = non_root[0] if non_root else ("app" if mysql else kind["super"])
        db_name = names[0] if names else slug(name)
        # passwords: new - but a database that exists already keeps the ones it was made with, so a .env written
        # before in this folder (--force) gives its values back
        had = parse_env(os.path.join(out, ".env")) if a.force else {}
        kept_pw = []
        for k in (["DB_ROOT_PASSWORD"] if mysql else []) + ["DB_PASSWORD"]:
            if had.get(k):
                menv[k] = had[k]
                kept_pw.append(k)
            else:
                menv[k] = secrets.token_urlsafe(18)
            mraw.pop(k, None)

        def pw_var(user):
            return "DB_ROOT_PASSWORD" if mysql and (user or "").lower() == "root" else "DB_PASSWORD"

        def inline(v, user_hint):
            """a connection string / URL to db with a password in it -> the same with ${DB_PASSWORD}
            (${DB_ROOT_PASSWORD} for root). Only those that point to db: a camera's password stays the camera's"""
            out_v = v
            csh = CS_HOST.search(v)
            if CS_PASS.search(v) and csh and csh.group(2).strip() == "db":
                um = CS_USER.search(v)
                var = pw_var(um.group(2).strip() if um else user_hint)
                out_v = CS_PASS.sub(lambda m: m.group(1) + "=${" + var + "}", out_v)
            m = URL_DB.match(out_v)
            if m and m.group("pw") and re.search(r"@db(:\d+)?/", out_v):
                var = pw_var(m.group("user"))
                out_v = URL_CRED.sub(lambda mm: mm.group(1) + "${" + var + "}" + mm.group(3), out_v)
            return out_v

        for n, svc in services.items():
            if "db" not in edges.get(n, ()):
                continue
            env = svc.get("environment") or {}
            per = settings_of(n)
            user_hint = next((v for k, v in per.items() if DB_USER_VAR.search(k) and v), None)
            for f, e in envfiles.items():
                if e["service"] != n:
                    continue
                keep = []
                for line in e["lines"]:
                    m = ENV_LINE.match(line)
                    if not m or line.lstrip().startswith("#"):
                        keep.append(line)
                        continue
                    k, v = m.group(1), env_value(m.group(2))
                    if DB_PASS_VAR.search(k):
                        var = pw_var(user_hint)
                        env[k] = "${" + var + "}"
                        keep.append(f"# {k}: in compose.yml now - ${{{var}}}, the database's password, written once in .env")
                        changes.append(f"  {n:<10} {k}: {f} -> compose.yml as ${{{var}}} (the new database's password)")
                        continue
                    nv = inline(v, user_hint)
                    if nv != v:
                        env[k] = nv
                        keep.append(f"# {k}: in compose.yml now - its password comes from .env")
                        changes.append(f"  {n:<10} {k}: {f} -> compose.yml, its password from .env")
                        continue
                    keep.append(line)
                e["lines"] = keep
            for k, v in list(env.items()):
                if not isinstance(v, str) or "${DB_" in v:
                    continue
                pure = REF.fullmatch(v.strip())
                val = menv.get(pure.group(1)) if pure else v
                if not val:
                    continue
                nv = "${" + pw_var(user_hint) + "}" if DB_PASS_VAR.search(k) else inline(val, user_hint)
                if nv != val:
                    env[k] = nv
                    if pure:
                        menv.pop(pure.group(1), None)
                    changes.append(f"  {n:<10} {k}: " + (f"in compose.yml now (was ${{{pure.group(1)}}} in .env)"
                                                         if pure else "in compose.yml") + ", its password from .env")
            if env:
                svc["environment"] = env
        # the database's clock: the programs' own time zone (TZ in their settings), else UTC
        tzs = [v for n in services if n in origin for k, v in settings_of(n).items() if k == "TZ" and v]
        tz = max(set(tzs), key=tzs.count) if tzs else None
        if mysql:
            dbsvc = {"image": "mysql:${MYSQL_VERSION:-8.4}", "restart": "unless-stopped",
                     "environment": {"MYSQL_ROOT_PASSWORD": "${DB_ROOT_PASSWORD:?DB_ROOT_PASSWORD is missing in .env}",
                                     "MYSQL_DATABASE": db_name, "MYSQL_USER": db_user,
                                     "MYSQL_PASSWORD": "${DB_PASSWORD:?DB_PASSWORD is missing in .env}"},
                     "volumes": ["dbdata:/var/lib/mysql", "./db/init:/docker-entrypoint-initdb.d:ro"],
                     "healthcheck": {"test": ["CMD-SHELL", "mysqladmin ping -h 127.0.0.1 -uroot "
                                                           "-p\"$$MYSQL_ROOT_PASSWORD\" --silent"],
                                     "interval": "5s", "timeout": "3s", "retries": 30, "start_period": "60s"}}
        else:                                                  # -h 127.0.0.1: healthy only once the first-start
            dbsvc = {"image": "postgres:${POSTGRES_VERSION:-17}", "restart": "unless-stopped",   # scripts are done
                     "environment": {"POSTGRES_DB": db_name, "POSTGRES_USER": db_user,
                                     "POSTGRES_PASSWORD": "${DB_PASSWORD:?DB_PASSWORD is missing in .env}"},
                     "volumes": ["dbdata:/var/lib/postgresql/data", "./db/init:/docker-entrypoint-initdb.d:ro"],
                     "healthcheck": {"test": ["CMD-SHELL", "pg_isready -h 127.0.0.1 -U \"$$POSTGRES_USER\" "
                                                           "-d \"$$POSTGRES_DB\""],
                                     "interval": "5s", "timeout": "3s", "retries": 30, "start_period": "60s"}}
        if tz:
            dbsvc["environment"]["TZ"] = tz
        publish = kind["publish"] if a.db_port is None else a.db_port
        if publish:
            dbsvc["ports"] = [f"127.0.0.1:{publish}:{kind['port']}"]
        services = {"db": dbsvc, **services}
        os.makedirs(os.path.join(out, "db", "init"), exist_ok=True)
        readme = os.path.join(out, "db", "init", "README.txt")
        if not os.path.exists(readme):
            with open(readme, "w", encoding="utf-8") as fh:
                fh.write("Put the database's structure here: 01-schema.sql (its tables and stored procedures, no rows).\n"
                         f"{kind['label']} runs the .sql files of this folder ONCE, in name order: on the first start of "
                         "an EMPTY database.\nDATABASE_WALKTHROUGH.md shows how to export it from the database you have "
                         "now.\n")
        users_now = [n for n in services if "db" in edges.get(n, ())]
        ver = kind["version"]
        dbinfo = [f"  db: {kind['label']} {ver} - database {db_name}, user {db_user} (password DB_PASSWORD)"
                  + (" and root (password DB_ROOT_PASSWORD), both" if mysql else ",")
                  + (" kept from the .env that was here (a database keeps the passwords of its first start)"
                     if kept_pw else " made new") + ", in .env",
                  "  On its first start it runs the .sql files of ./db/init, and holds only what they make: your tables",
                  "  (01-schema.sql), and your rows too if the file has them. Your current database is not changed."]
        if publish:
            dbinfo.append(f"  To look into it from this PC ({kind['tool']}): 127.0.0.1, port {publish}, user {db_user}, "
                          "its password from .env")
        dbinfo.append(f"  Its clock: TZ={tz}, from the programs' settings" if tz else
                      "  Its clock runs in UTC (no TZ in the programs' settings): if your SQL uses NOW(), add TZ under "
                      "db's environment (e.g. TZ: IST-5:30)")
        dbinfo.append(f"  uses it: {', '.join(users_now)}" if users_now else
                      "  NO program's settings point to a database - it runs, nothing uses it yet")
        others = [u for u in non_root if u != db_user] + ([kind["super"]] if not mysql and db_user != kind["super"]
                                                          and any(u.lower() == kind["super"] for u in users) else [])
        if others:
            dbinfo.append(f"  the settings also log in as {', '.join(others)}: only {db_user} is made - make the others "
                          "in ./db/init/00-users.sql (" + ("CREATE USER ... GRANT ..." if mysql else
                                                               "CREATE ROLE ... LOGIN PASSWORD ...; GRANT ...") + ")")
        if len(names) > 1:
            dbinfo.append(f"  the settings also use the database(s) {', '.join(names[1:])}: only {db_name} is made - "
                          f"make the others in ./db/init/00-databases.sql and GRANT {db_user} on them")
        if mysql and any((u or "").lower() == "root" for u in users):
            dbinfo.append("  a program logs in as root: it gets DB_ROOT_PASSWORD. Better: its own user (made in db/init)")

    # ---- the start order: a program that calls another starts once that one answers
    order = []
    for n, svc in services.items():
        if n == "db" or svc.get("healthcheck"):
            continue
        cmd = svc.get("command") or svc.get("entrypoint") or []
        cmd = cmd if isinstance(cmd, list) else str(cmd).split()
        called = any(n in tos for c, tos in edges.items() if c != n)
        t, _p = listen[n]
        if called and t and cmd and "python" in os.path.basename(str(cmd[0])).lower():
            port = sorted(t)[0]
            dep = json.dumps(svc.get("deploy") or {})
            gpu = "nvidia" in dep or "gpu" in dep or bool(svc.get("gpus"))
            svc["healthcheck"] = {"test": ["CMD", cmd[0], "-c",
                                           f"import socket; socket.create_connection(('127.0.0.1', {port}), 3)"],
                                  "interval": "10s", "timeout": "5s", "retries": 3,
                                  "start_period": "180s" if gpu else "30s"}
            order.append(f"  {n}: healthy = it accepts a connection on port {port} (checked every 10 s"
                         + (", up to 3 min for the model to load)" if gpu else ")"))
    for n, svc in services.items():
        tos = sorted(x for x in edges.get(n, ()) if x in services and x != n)
        if not tos:
            continue
        dep = svc.get("depends_on") if isinstance(svc.get("depends_on"), dict) else {}
        for t2 in tos:
            cond = "service_healthy" if services[t2].get("healthcheck") else "service_started"
            dep.setdefault(t2, {"condition": cond})
            order.append(f"  {n} starts after {t2} is {'healthy' if cond == 'service_healthy' else 'started'}")
        for d in dep.values():
            if isinstance(d, dict) and d.get("required") is True:
                d.pop("required")
        svc["depends_on"] = dep

    # ---- images: their versions in .env (a new version: one line); a service that was built gets its image's name
    for n, svc in services.items():
        if n == "db":
            continue
        s, old = origin[n]
        if "build" in svc:
            if not svc.get("image"):
                svc["image"] = f"{s['doc'].get('name') or os.path.basename(s['dir'])}-{old}"
            notes.append(f"  {n}: build: left out - build it in its own folder as before ({s['dir']}); this file runs "
                         f"the image {svc['image']}")
            svc.pop("build")
        img = svc.get("image")
        if not img or "${" in img or "@" in img:
            continue
        last = img.rsplit("/", 1)[-1]
        repo, tag = img.rsplit(":", 1) if ":" in last else (img, "latest")
        var = slug(repo.rsplit("/", 1)[-1], upper=True) + "_VERSION"
        if var in menv and menv[var] != tag:
            var = slug(n, upper=True) + "_VERSION"
        menv[var], mraw[var] = tag, None
        svc["image"] = f"{repo}:${{{var}:-{tag}}}"
    if db:
        menv[kind["var"]], mraw[kind["var"]] = kind["version"], None

    # ---- left out: the networks added to join the files (one network now), container names, legacy links
    removed, nets = [], set()
    for s in srcs:
        proj = s["doc"].get("name") or os.path.basename(s["dir"])
        for nn, nd in (s["doc"].get("networks") or {}).items():
            nd = nd or {}
            if nd.get("external") or (nd.get("name") and nd["name"] != f"{proj}_{nn}"):
                nets.add(nd.get("name") or nn)
    for n, svc in services.items():
        for k in ("networks", "links", "external_links"):
            svc.pop(k, None)
        if n in origin and svc.get("extra_hosts"):            # host.docker.internal, needed before to reach the others
            mine = json.dumps([x for e in envfiles.values() if e["service"] == n for x in e["lines"]
                               if not x.lstrip().startswith("#")])
            mine += json.dumps(svc.get("environment") or {}) + json.dumps({k: menv.get(k) for k in refs_in(svc)})
            eh = svc["extra_hosts"]
            items = eh if isinstance(eh, list) else [f"{k}:{v}" if not isinstance(v, list) else f"{k}:{v[0]}"
                                                     for k, v in eh.items()]
            keep = [x for x in items if not str(x).startswith("host.docker.internal")]
            if len(keep) < len(items) and "host.docker.internal" not in mine:
                removed.append(f"  {n}: extra_hosts host.docker.internal - its settings do not use it any more")
                if keep:
                    svc["extra_hosts"] = keep
                else:
                    svc.pop("extra_hosts")
        if svc.get("network_mode") in ("bridge", "default"):
            removed.append(f"  {n}: network_mode {svc.pop('network_mode')} - it is on the system's network now")
        elif svc.get("network_mode"):
            notes.append(f"  {n}: network_mode {svc['network_mode']} kept - it is NOT on the system's network: the "
                         "others do not reach it by its name")
        if svc.pop("container_name", None):
            removed.append(f"  {n}: container_name - the others reach it by its service name, {n}")
        if isinstance(svc.get("ports"), list):
            svc["ports"] = [(f"{p['host_ip']}:" if p.get("host_ip") else "") + f"{p['published']}:{p['target']}"
                            + ("/udp" if p.get("protocol") == "udp" else "")
                            if isinstance(p, dict) and p.get("published") else
                            (str(p["target"]) if isinstance(p, dict) else p) for p in svc["ports"]]
    if nets:
        removed.insert(0, f"  the network(s) {', '.join(sorted(nets))} added to join the files: not needed - every "
                          f"service is on this file's own network ({name}_default)")

    # ---- write compose.yml
    vols = {}
    for s in srcs:
        for vn, vd in (s["doc"].get("volumes") or {}).items():
            vd = dict(vd or {})
            if not vd.get("external"):
                vd.pop("name", None)
            vols[vn] = vd
    if db:
        vols["dbdata"] = {}
    used = refs_in(services)
    L = [f"# The whole system in one file - written by xray_merge.py {VERSION} on {datetime.date.today()} from:"]
    L += [f"#   {s['path']}" for s in srcs]
    L += ["# One network: the services reach each other by their service names. Settings: .env (what compose fills",
          "# in: versions, passwords) and NAME.env (each program's own). merge.txt: what was changed and why.",
          "#   docker compose config -q     docker compose up -d --wait     docker compose ps     docker compose logs -f",
          f"name: {name}", "", "services:"]
    for n, svc in services.items():
        if n in origin:
            s, old = origin[n]
            L.append(f"  # from {s['path']}" + (f" (service {old} there)" if old != n else ""))
        else:
            L.append(f"  # the system's own {kind['label']}: its data in the volume dbdata; its tables, the first time, "
                     "from ./db/init")
        L.append(f"  {n}:")
        L += to_yaml(svc, 2, KEY_ORDER[:9] + ["ports", "depends_on", "healthcheck", "deploy"])
        L.append("")
    if vols:
        L.append("volumes:")
        for vn, vd in vols.items():
            L.append(f"  {vn}:" + ("" if vd else " {}"))
            if vd:
                L += to_yaml(vd, 2)
    with open(os.path.join(out, "compose.yml"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(L).rstrip() + "\n")

    # ---- .env and the NAME.env files
    keys = [k for k in menv if k in used]
    E = [f"# .env of {name} - compose fills these into compose.yml (${{NAME}}). Written by xray_merge.py.",
         "# Never commit it (it holds passwords). xray_clients.py gives each client a copy with new passwords.", ""]
    ver = sorted(k for k in keys if k.endswith("_VERSION"))
    if ver:
        E += ["# the images' versions - a new version: change its line, then  docker compose up -d"]
        E += [env_line(k, menv[k]) for k in ver] + [""]
    pw = [k for k in ("DB_ROOT_PASSWORD", "DB_PASSWORD") if k in keys]
    if pw:
        E += ["# the database's passwords - the programs get them from here, through compose.yml. The database takes them",
              "# at its FIRST start only: changing them here later does not change them in the database"]
        E += [env_line(k, menv[k]) for k in pw] + [""]
    rest = [k for k in keys if k not in ver and k not in pw]
    if rest:
        E += ["# the rest"]
        E += [mraw[k] if mraw.get(k) and env_value(mraw[k].split("=", 1)[1]) == menv[k] else env_line(k, menv[k])
              for k in rest]
    with open(os.path.join(out, ".env"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(E).rstrip() + "\n")
    for f, e in envfiles.items():
        with open(os.path.join(out, f), "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(e["lines"]).rstrip() + "\n")

    # ---- merge.txt: the report
    T = [f"xray_merge {VERSION}: {len(srcs)} compose file(s) -> ONE: {os.path.join(out, 'compose.yml')}   (project {name})",
         "", "SERVICES"]
    for n, svc in services.items():
        if n in origin:
            s, old = origin[n]
            T.append(f"  {n:<10} {svc.get('image')}   from {s['path']}" + (f" (service {old} there)" if old != n else ""))
        else:
            T.append(f"  {n:<10} {svc.get('image')}   the system's own {kind['label']} (--db {a.db})")
    T += ["", "ADDRESSES - a service reaches another by its name and the port INSIDE that container"]
    T += changes or ["  nothing to change"]
    if outside:
        T += ["", "OUTSIDE THIS SYSTEM - left as they are (cameras, a database on this PC or elsewhere ...)"]
        T += sorted(set(outside))
    T += ["", "START ORDER"] + (order or ["  no service calls another (by the settings): no order needed"])
    if dbinfo:
        T += ["", f"THE DATABASE (--db {a.db})"] + dbinfo
    rows = [("compose.yml", "the system"),
            (".env", ", ".join(keys) if keys else "(nothing for compose to fill in)")]
    rows += [(f, f"from {e['src']}") for f, e in envfiles.items()]
    rows += [(rel[2:] + "/", f"{n} writes here - before: {full} (copy over what you still need)") for rel, full, n in made]
    if db:
        rows += [("db/init/", "the database's first-start scripts: put 01-schema.sql here")]
    w = max(len(r[0]) for r in rows) + 2
    T += ["", f"FILES IN {out}"] + [f"  {a_:<{w}}{b_}" for a_, b_ in rows]
    if kept:
        T += [""] + kept
    if removed:
        T += ["", "LEFT OUT"] + removed
    pub = [f"{n} {' '.join(str(x) for x in svc['ports'])}" for n, svc in services.items() if svc.get("ports")]
    if pub:
        T += ["", "PORTS - kept: the way in from this PC (the services reach each other without them): " + "; ".join(pub)]
    if old_vols:
        notes.append(f"  volumes of a compose project named {name} exist already ({', '.join(old_vols)}): this file uses "
                     "them, with the data in them. For a fresh start: another --name, or remove them first "
                     "(docker volume rm NAME) if they hold nothing you need")
    if notes:
        T += ["", "NOTES"] + notes
    T += ["", "NEXT",
          "  1. stop the old ones - in each old compose file's folder:  docker compose -f FILE down",
          f"  2. cd \"{out}\"",
          "  3. docker compose config -q          nothing printed = the file is right",
          "  4. docker compose up -d --wait       it returns when every service runs (and answers its healthcheck)",
          "  5. docker compose ps                 then:  docker compose logs --tail 5 SERVICE"]
    if nets:
        T += ["  6. once nothing uses it any more:   " + "   ".join(f"docker network rm {x}" for x in sorted(nets))]
    report = "\n".join(T) + "\n"
    with open(os.path.join(out, "merge.txt"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(report)
    print(report, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
