#!/usr/bin/env python3
"""
xray_release.py - one release of a project: every X-Ray step again, in a row, and the slim image with its version.

    python xray_release.py --name app --version 1.4.0
    python xray_release.py --name app --version 1.4.0 --registry SERVER:5443 --push

For a project that has been through the steps once (GUIDE.md / XRAY_WALKTHROUGH.html): runs/NAME/ holds its Step 1
map and its run files. A release runs, in this order, and stops at the first step that fails:

  1. Step 1 again (xray_static.py, with the options of the last time) -> step1.log, step1-needs.txt
  2. the requirements: Dockerfile.naive must be written from today's requirements file. With --naive it is written
     again (xray_naive.py, the options of the last time) and copied into the project
  3. the run files again (xray_runfile.py, the options of the last time). Your settings at the top of the run files
     (RUN_SECONDS, SOURCE ...) and your values in run.env stay. --keep-runfiles: use them as they are
  4. build-naive, run-step2 (the program must end well, or be stopped by RUN_SECONDS), run-step3-4, build-slim,
     run-slim: verify.txt must end with VERDICT: PASS
  5. the version: NAME-slim:VERSION and NAME-naive:VERSION. With --registry also REGISTRY/NAME-slim:VERSION,
     pushed with --push (docker login REGISTRY once before)
  6. runs/NAME/releases/VERSION.txt: what went into it (git commit, tool versions, images and sizes, the verdict),
     with the plan's Dockerfile and verify.txt beside it. The whole output: runs/NAME/releases/VERSION.log

Python standard library only. On Linux with --naive, run it with the venv's Python (xray_naive.py needs pip):
    ~/xray-venv/bin/python xray_release.py --name app --version 1.4.0 --naive
"""
import argparse
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import time

VERSION = "0.1.0"
HERE = os.path.dirname(os.path.abspath(__file__))
WIN = os.name == "nt"
EXT = ".bat" if WIN else ".sh"
TOOLS = ("xray_static.py", "xray_needs.py", "xray_naive.py", "xray_runfile.py", "xray_trace.py", "xray_pkg.py",
         "xray_plan.py", "xray_release.py")
TAG_OK = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$")       # what docker takes as a tag


class Stop(Exception):
    """a step failed: the release stops, with what to do"""


class Log:
    """everything to the screen and to releases/VERSION.log"""

    def __init__(self, path):
        self.fh = open(path, "w", encoding="utf-8")

    def say(self, line=""):
        print(line, flush=True)
        self.write(line)

    def write(self, line):
        self.fh.write(line + "\n")
        self.fh.flush()


def jload(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def took(sec):
    sec = int(round(sec))
    return f"{sec // 60} min {sec % 60} s" if sec >= 60 else f"{sec} s"


def mb(n):
    return f"{n / 1e6:.0f} MB" if n < 1e9 else f"{n / 1e9:.2f} GB"


def run(cmd, log, cwd=None, env=None, show=True, also=None):
    """runs cmd: its output to the screen (show) and to the release log (and to the file also) -> exit code"""
    try:
        p = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except OSError as e:
        raise Stop(f"could not start {cmd[0]}: {e}")
    fh = open(also, "w", encoding="utf-8") if also else None
    try:
        for raw in p.stdout:
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if fh:
                fh.write(line + "\n")
            if show:
                log.say("    " + line)
            else:
                log.write("    " + line)
    finally:
        if fh:
            fh.close()
    return p.wait()


def docker(args, log, show=False):
    """a docker command -> (exit code, its output)"""
    try:
        r = subprocess.run(["docker"] + args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    except OSError as e:
        raise Stop(f"docker could not be started ({e}): is Docker installed, and is this the terminal you use it in?")
    out = (r.stdout + r.stderr).strip()
    log.write("    $ docker " + " ".join(args) + ("\n    " + out.replace("\n", "\n    ") if out else ""))
    if show and out:
        print("    " + out.replace("\n", "\n    "), flush=True)
    return r.returncode, out


def image(ref, log):
    """(id, size in bytes) of a local image, or None"""
    rc, out = docker(["image", "inspect", "--format", "{{.Id}} {{.Size}}", ref], log)
    if rc != 0 or not out:
        return None
    i, size = out.split()[:2]
    return i, int(size)


def git_state(folder):
    """'abc1234' / 'abc1234 + uncommitted changes' / None (not a git folder, or no git)"""
    try:
        h = subprocess.run(["git", "-C", folder, "rev-parse", "--short", "HEAD"], capture_output=True, text=True)
        if h.returncode != 0:
            return None
        d = subprocess.run(["git", "-C", folder, "status", "--porcelain"], capture_output=True, text=True)
    except OSError:
        return None
    return h.stdout.strip() + (" + uncommitted changes" if d.stdout.strip() else "")


def tool_versions():
    out = []
    for t in TOOLS:
        try:
            with open(os.path.join(HERE, t), encoding="utf-8") as fh:
                m = re.search(r'^VERSION = "([^"]+)"', fh.read(), re.M)
            out.append(f"{t[:-3]} {m.group(1) if m else '?'}")
        except OSError:
            pass
    return ", ".join(out)


def req_lines(path):
    """the requirement lines of a requirements file, cleaned as xray_naive.py cleans them"""
    out = []
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        for raw in fh.read().splitlines():
            line = raw.split(" #", 1)[0].strip()
            if line and not line.startswith(("#", "-")):
                out.append(line)
    return out


def docker_req_lines(path):
    """the lines requirements.docker.txt was written from: each requirement line, kept, changed or left out"""
    seen = set()
    with open(path, encoding="utf-8", errors="replace") as fh:
        for raw in fh.read().splitlines():
            s = raw.strip()
            if s.startswith("# + "):
                continue
            if s.startswith("# "):
                s = s[2:]
            seen.add(s.split("    ", 1)[0].strip())
    return seen


def fresh(path, since):
    """written by this release (not a file of the release before)"""
    try:
        return os.path.getmtime(path) >= since - 1
    except OSError:
        return False


def build_failed(log_path):
    try:
        with open(log_path, encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError:
        return True
    return bool(re.search(r"^ERROR\b|failed to solve", text, re.M))


def tail(path, n=20):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read().splitlines()[-n:]
    except OSError:
        return []


def main(argv=None):
    for _s in (sys.stdout, sys.stderr):
        if hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="one release: every X-Ray step again, then the slim image with its version")
    ap.add_argument("--name", required=True, help="the short name: runs/NAME/ (made by the steps the first time)")
    ap.add_argument("--version", required=True, help="the release's version, the images' tag: 1.4.0")
    ap.add_argument("--project", help="the project folder (default: the one of the last Step 1)")
    ap.add_argument("--naive", action="store_true",
                    help="write Dockerfile.naive again from the requirements file (xray_naive.py, the options of the "
                         "last time) and copy it into the project - after a change of the requirements")
    ap.add_argument("--skip-requirements-check", action="store_true",
                    help="build even when the requirements file has lines Dockerfile.naive was not written from (you "
                         "added them to Dockerfile.naive by hand)")
    ap.add_argument("--keep-runfiles", action="store_true",
                    help="use the run files as they are (default: written again - your settings at their top and in "
                         "run.env stay)")
    ap.add_argument("--exclude", action="append", help="Step 1's --exclude, when Step 1 was made by xray_static older "
                                                       "than 0.5.22 (newer ones keep their options)")
    ap.add_argument("--path", action="append", help="Step 1's --path, the same way")
    ap.add_argument("--registry", help="the image registry, e.g. 192.168.1.50:5443: tags REGISTRY/NAME-slim:VERSION")
    ap.add_argument("--push", action="store_true", help="push REGISTRY/NAME-slim:VERSION (docker login REGISTRY once)")
    ap.add_argument("--push-naive", action="store_true", help="push REGISTRY/NAME-naive:VERSION too")
    ap.add_argument("--again", action="store_true", help="release a version that was released before (its tags move)")
    a = ap.parse_args(argv)

    name, ver = a.name, a.version
    if not TAG_OK.match(ver):
        sys.exit(f"--version {ver}: letters, digits, '.', '-', '_' only (it becomes the images' tag), e.g. 1.4.0")
    if (a.push or a.push_naive) and not a.registry:
        sys.exit("--push needs --registry REGISTRY (the address the images go to, e.g. 192.168.1.50:5443)")
    run_dir = os.path.join(HERE, "runs", name)
    static_path = os.path.join(run_dir, name + ".json")
    if not os.path.isfile(static_path):
        sys.exit(f"{static_path} is missing: a release repeats the steps of a project that went through them once. "
                 "The first time, follow GUIDE.md / XRAY_WALKTHROUGH.html (Step 1, xray_naive.py, xray_runfile.py).")
    rel_dir = os.path.join(run_dir, "releases")
    os.makedirs(rel_dir, exist_ok=True)
    record = os.path.join(rel_dir, ver + ".txt")
    if os.path.isfile(record) and not a.again:
        sys.exit(f"version {ver} of {name} was released before ({record}). Give the next version, or --again to "
                 "release this one again (its tags then move to the new images).")
    log = Log(os.path.join(rel_dir, ver + ".log"))
    started = time.time()
    steps, tagged = [], []
    step = "the settings"
    try:
        rc, out = docker(["info", "--format", "{{.ServerVersion}}"], log)
        if rc != 0:
            raise Stop("Docker does not answer: start Docker Desktop (Windows) / sudo systemctl start docker (Linux)")
        log.say(f"xray_release {VERSION}: {name} {ver} - {datetime.datetime.now():%Y-%m-%d %H:%M}, Docker {out}")

        # ------------------------------------------------------------------ the settings of the last time
        st = jload(static_path)
        o = st.get("options")
        if o:
            root, entries, cwd = o["root"], o["entry"], o.get("cwd") or "."
            reqs, paths, excl, inst = o.get("requirements") or [], o.get("path") or [], o.get("exclude") or [], \
                o.get("use_installed")
        else:
            root, entries, cwd = st["root"], st.get("entrypoints") or [], st.get("cwd") or "."
            reqs, paths, excl, inst = st.get("requirements_files") or [], [], [], False
            log.say("  NOTE: this Step 1 map is older than xray_static 0.5.22 and does not keep its options: project, "
                    "entry, cwd and requirements are taken from it; give --exclude / --path if Step 1 had them")
        if a.project:
            root = os.path.abspath(a.project)
        if a.exclude is not None:
            excl = a.exclude
        if a.path is not None:
            paths = a.path
        if not os.path.isdir(root):
            raise Stop(f"the project folder {root} is not there - give it with --project")
        if not entries:
            raise Stop(f"{static_path} names no entry file")
        g = git_state(root)
        log.say(f"  project  {root}   entry {', '.join(entries)}   requirements {', '.join(reqs) or 'none'}")
        log.say(f"  git      {g or 'not a git folder'}")
        if g and "uncommitted" in g:
            log.say("           (the release is built from files not committed yet: commit them, so the version can be "
                    "found again)")
        PY = sys.executable

        # ------------------------------------------------------------------ 1. Step 1 again
        step, t = "Step 1 (xray_static.py)", time.time()
        log.say(f"\n[1/8] {step}")
        cmd = [PY, os.path.join(HERE, "xray_static.py"), "--root", root, "--cwd", cwd, "--out", static_path]
        for e in entries:
            cmd += ["--entry", e]
        for r in reqs:
            cmd += ["--requirements", r]
        for p in paths:
            cmd += ["--path", p]
        for x in excl:
            cmd += ["--exclude", x]
        if inst:
            cmd.append("--use-installed")
        if run(cmd, log, also=os.path.join(run_dir, "step1.log")) != 0:
            raise Stop(f"Step 1 failed - read {os.path.join(run_dir, 'step1.log')}")
        needs = os.path.join(run_dir, "step1-needs.txt")
        run([PY, os.path.join(HERE, "xray_needs.py"), static_path], log, show=False, also=needs)
        changes, on = [], False
        for line in open(needs, encoding="utf-8", errors="replace").read().splitlines():
            if line.startswith("CODE CHANGES NEEDED"):
                on = True
                continue
            if on and line.strip():
                changes.append(line)
            elif on:
                break
        if changes and not (len(changes) == 1 and "none found" in changes[0]):
            log.say("    CODE CHANGES NEEDED (step1-needs.txt) - the runs may need them:")
            for c in changes[:12]:
                log.say("    " + c)
        steps.append((step, time.time() - t))

        # ------------------------------------------------------------------ 2. the requirements
        step, t = "the requirements", time.time()
        log.say(f"\n[2/8] {step}")
        req0 = reqs[0] if reqs else None
        req_path = (req0 if req0 and os.path.isabs(req0) else os.path.join(root, req0)) if req0 else None
        if a.naive:
            nj_path = os.path.join(run_dir, "naive", "naive-check.json")
            nj = jload(nj_path) if os.path.isfile(nj_path) else {}
            no = nj.get("options") or {}
            if not (req0 or no.get("requirements")):
                raise Stop("--naive: no requirements file is known for this project")
            cmd = [PY, os.path.join(HERE, "xray_naive.py"), "--project", root, "--requirements",
                   no.get("requirements") or req0, "--entry", no.get("entry") or entries[0], "--name", name,
                   "--static", static_path]
            if no:                                   # as typed the last time
                if no.get("python"):
                    cmd += ["--python", no["python"]]
                cmd += ["--gpu"] if no.get("gpu") else ["--cpu"] if no.get("cpu") else []
                cmd += ["--arch", no.get("arch") or "x86_64"]
                for k in ("copy", "mount", "keep"):
                    for v in no.get(k) or []:
                        cmd += ["--" + k, v]
            elif nj:                                 # older naive-check.json: what it decided
                cmd += ["--python", str(nj.get("python") or "3.12"), "--gpu" if nj.get("gpu") else "--cpu",
                        "--arch", nj.get("arch") or "x86_64"]
            rc = run(cmd, log, also=os.path.join(run_dir, "naive.log"))
            if rc != 0:
                nolog = "".join(tail(os.path.join(run_dir, "naive.log"), 400))
                raise Stop("xray_naive.py: " + ("this Python has no pip - run this script with ~/xray-venv/bin/python "
                                                "(LINUX_GUIDE 1)" if "No module named pip" in nolog else
                                                f"requirements that cannot be installed for Linux (exit code {rc}) - "
                                                f"read {os.path.join(run_dir, 'naive', 'naive-check.txt')}"))
            for f in ("Dockerfile.naive", "Dockerfile.naive.dockerignore", "requirements.docker.txt"):
                shutil.copyfile(os.path.join(run_dir, "naive", f), os.path.join(root, f))
            log.say("    Dockerfile.naive, Dockerfile.naive.dockerignore, requirements.docker.txt copied into the project")
        elif req_path and os.path.isfile(req_path) and not a.skip_requirements_check:
            dreq = next((p for p in (os.path.join(root, "requirements.docker.txt"),
                                     os.path.join(run_dir, "naive", "requirements.docker.txt")) if os.path.isfile(p)),
                        None)
            if dreq:
                missing = [line for line in req_lines(req_path) if line not in docker_req_lines(dreq)]
                if missing:
                    raise Stop(f"{req0} has lines Dockerfile.naive was not written from: {', '.join(missing[:8])}"
                               f"{' ...' if len(missing) > 8 else ''}. Add --naive (Dockerfile.naive is written again "
                               "from the requirements and checked for Linux), or --skip-requirements-check if you put "
                               "them into Dockerfile.naive by hand")
                log.say(f"    {req0}: every line is in Dockerfile.naive (checked against {dreq})")
            else:
                log.say("    no requirements.docker.txt to check against - Dockerfile.naive is used as it is")
        else:
            log.say("    not checked" + (" (--skip-requirements-check)" if a.skip_requirements_check else
                                         " (no requirements file)"))
        if not os.path.isfile(os.path.join(root, "Dockerfile.naive")):
            raise Stop(f"no Dockerfile.naive in {root}: copy it from {os.path.join(run_dir, 'naive')} "
                       "(GUIDE 3b), or add --naive")
        steps.append((step, time.time() - t))

        # ------------------------------------------------------------------ 3. the run files
        step, t = "the run files (xray_runfile.py)", time.time()
        log.say(f"\n[3/8] {step}")
        rj_path = os.path.join(run_dir, "runfile.json")
        ro = (jload(rj_path).get("options") or {}) if os.path.isfile(rj_path) else {}
        if a.keep_runfiles:
            log.say("    kept as they are (--keep-runfiles)")
        else:
            cmd = [PY, os.path.join(HERE, "xray_runfile.py"), "--static", static_path, "--project", root, "--name", name]
            for k in ("image", "dockerfile", "mac", "shell"):
                if ro.get(k):
                    cmd += ["--" + k.replace("_", "-"), str(ro[k])]
            if ro.get("stop_after") is not None:
                cmd += ["--stop-after", str(ro["stop_after"])]
            if not ro:                     # run files of xray_runfile older than 0.2.17: a --mac given then is in them
                try:
                    with open(os.path.join(run_dir, "run-step2" + EXT), encoding="utf-8", errors="replace") as fh:
                        m = re.search(r"--mac-address ([0-9a-fA-F:]{17})", fh.read())
                    if m:
                        cmd += ["--mac", m.group(1)]
                except OSError:
                    pass
            if run(cmd, log) != 0:
                raise Stop("xray_runfile.py failed - its message is above")
        steps.append((step, time.time() - t))

        # ------------------------------------------------------------------ 4. the run files, in a row
        env = dict(os.environ, XRAY_QUIET="1")       # the .bat files open no Notepad
        img = ro.get("image") or name + "-naive"

        def runfile(base, k):
            nonlocal step
            step = base + EXT
            log.say(f"\n[{k}/8] {step}")
            path = os.path.join(run_dir, base + EXT)
            if not os.path.isfile(path):
                raise Stop(f"{path} is missing")
            t0 = time.time()
            rc = run(["cmd", "/c", path] if WIN else ["bash", path], log, cwd=run_dir, env=env)
            return rc, t0

        rc, t0 = runfile("build-naive", 4)
        if rc != 0 or build_failed(os.path.join(run_dir, "build.log")):
            raise Stop(f"the naive image did not build - the end of {os.path.join(run_dir, 'build.log')} says why")
        steps.append((step, time.time() - t0))

        rc, t0 = runfile("run-step2", 5)
        rt = os.path.join(run_dir, name + "-runtime.json")
        if not fresh(rt, t0):
            raise Stop(f"Step 2 wrote no new record of the run - read {os.path.join(run_dir, 'step2.log')}")
        scen = jload(rt).get("scenario")
        for sc in (scen if isinstance(scen, list) else [scen]):
            sc = sc or {}
            if sc.get("exit_code") not in (0, None) and not sc.get("stopped_by"):
                lines = tail(os.path.join(run_dir, "step2.log"), 12)
                raise Stop(f"the program ended with exit code {sc.get('exit_code')} in the naive image, so there is "
                           "nothing good to compare the slim image with. The end of step2.log:\n      "
                           + "\n      ".join(lines))
        steps.append((step, time.time() - t0))

        rc, t0 = runfile("run-step3-4", 6)
        if not fresh(os.path.join(run_dir, "plan", "Dockerfile"), t0):
            raise Stop(f"Steps 3-4 made no new plan - read {os.path.join(run_dir, 'step3.txt')} and step4.txt")
        steps.append((step, time.time() - t0))

        rc, t0 = runfile("build-slim", 7)
        if rc != 0 or build_failed(os.path.join(run_dir, "build-slim.log")):
            raise Stop(f"the slim image did not build - the end of {os.path.join(run_dir, 'build-slim.log')} says why")
        steps.append((step, time.time() - t0))

        rc, t0 = runfile("run-slim", 8)
        vt = os.path.join(run_dir, "verify.txt")
        if not fresh(vt, t0):
            raise Stop(f"the slim run wrote no verify.txt - read {os.path.join(run_dir, 'step2-slim.log')}")
        vlines = [x for x in open(vt, encoding="utf-8", errors="replace").read().splitlines() if x.strip()]
        verdict = vlines[-1] if vlines else ""
        steps.append((step, time.time() - t0))
        if not verdict.startswith("VERDICT: PASS"):
            raise Stop("the slim image did not do everything the naive one did:\n      " + "\n      ".join(vlines[-14:]))
        log.say(f"\n    {verdict}")

        # ------------------------------------------------------------------ 5. the version
        step = "the version tags"
        log.say(f"\n[tags] {name}-slim:{ver}, {img}:{ver}")
        for src in (name + "-slim", img):
            rc, out = docker(["tag", src, f"{src}:{ver}"], log)
            if rc != 0:
                raise Stop(f"docker tag {src} {src}:{ver}: {out}")
            tagged.append(f"{src}:{ver}")
        pushed = []
        if a.registry:
            reg = a.registry.rstrip("/")
            for src, push in ((name + "-slim", a.push), (img, a.push_naive)):
                dst = f"{reg}/{src}:{ver}"
                rc, out = docker(["tag", src, dst], log)
                if rc != 0:
                    raise Stop(f"docker tag {src} {dst}: {out}")
                tagged.append(dst)
                if push:
                    step = "docker push " + dst
                    log.say(f"\n[push] {dst}")
                    t0 = time.time()
                    if run(["docker", "push", dst], log) != 0:
                        raise Stop(f"the push of {dst} failed: the message is above. Not logged in: docker login {reg}. "
                                   "A certificate error: the registry's certificate is not trusted on this PC "
                                   "(DEV_PIPELINE.md, the registry)")
                    pushed.append(dst)
                    steps.append(("push " + src, time.time() - t0))

        # ------------------------------------------------------------------ 6. the record
        step = "the record"
        slim, naive = image(f"{name}-slim:{ver}", log), image(f"{img}:{ver}", log)
        for src, dst in ((vt, ver + "-verify.txt"), (os.path.join(run_dir, "plan", "Dockerfile"), ver + ".Dockerfile")):
            shutil.copyfile(src, os.path.join(rel_dir, dst))
        R = [f"X-Ray release {ver} of {name} - {datetime.datetime.now():%Y-%m-%d %H:%M}",
             f"  verdict   {verdict}",
             f"  project   {root}   git {g or 'not a git folder'}",
             f"  images    {name}-slim:{ver}   {slim[0][:19] if slim else '?'}   {mb(slim[1]) if slim else '?'}",
             f"            {img}:{ver}   {naive[0][:19] if naive else '?'}   {mb(naive[1]) if naive else '?'}"]
        R += [f"  pushed    {p}" for p in pushed]
        R += [f"  tools     {tool_versions()}",
              "  steps     " + ", ".join(f"{s} {took(d)}" for s, d in steps),
              f"  beside it {ver}.Dockerfile (the slim image's Dockerfile), {ver}-verify.txt, {ver}.log (all output)",
              f"  in production: image: {(pushed[0] if pushed else name + '-slim:' + ver)}"]
        with open(record, "w", encoding="utf-8") as fh:
            fh.write("\n".join(R) + "\n")
        log.say("\n" + "=" * 100)
        log.say(f"RELEASE {ver} of {name}: {verdict}   ({took(time.time() - started)})")
        log.say(f"  {name}-slim:{ver}  {mb(slim[1]) if slim else '?'}      {img}:{ver}  {mb(naive[1]) if naive else '?'}")
        for p in pushed:
            log.say(f"  pushed: {p}")
        prod = pushed[0] if pushed else f"{name}-slim:{ver}"
        log.say(f"  production: in the compose file, image: {prod}  - then docker compose up -d "
                f"(the version before: its tag again, up -d again)")
        log.say(f"  record: {record}")
        return 0
    except Stop as e:
        log.say("\n" + "=" * 100)
        log.say(f"RELEASE {ver} of {name} STOPPED at {step}:")
        log.say("  " + str(e))
        log.say(f"  Tagged already: {', '.join(tagged)} (the images passed; only what follows failed)" if tagged else
                f"  Nothing was tagged {ver}.")
        log.say(f"  The whole output: {os.path.join(rel_dir, ver + '.log')}")
        return 1
    except KeyboardInterrupt:
        log.say(f"\nRELEASE {ver} of {name} STOPPED (Ctrl+C) at {step}. "
                + (f"Tagged already: {', '.join(tagged)}." if tagged else f"Nothing was tagged {ver}."))
        return 130


if __name__ == "__main__":
    sys.exit(main())
