#!/usr/bin/env bash
# Deletes one version of one image from the registry and frees the disk space only that version used
# (DEV_PIPELINE.md 5.5). Run it on the registry's server, next to compose.yml:
#     bash delete-version.sh app-slim 1.4.0
# It asks for a registry user and password. The registry stops for the clean-up (a minute or so): Docker's rule -
# no pushes while it frees space. Its own --delete-untagged option is NOT used: with the images Docker builds today
# (an index + its parts) it also deletes parts of versions that stay (tested: the version kept could no longer be pulled).
set -u
NAME="${1:?usage: bash delete-version.sh IMAGE VERSION     e.g.  bash delete-version.sh app-slim 1.4.0}"
VER="${2:?usage: bash delete-version.sh IMAGE VERSION}"
cd "$(dirname "$0")" || exit 1
ADDR=$(grep -E '^REGISTRY_ADDRESS=' .env 2>/dev/null | cut -d= -f2 | tr -d '\r')
[ -n "$ADDR" ] || { echo "REGISTRY_ADDRESS is missing in .env (next to compose.yml)"; exit 1; }
[ -s caddy-root.crt ] || docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt ./caddy-root.crt \
  || { echo "could not get Caddy's root certificate - is the registry running (docker compose up -d)?"; exit 1; }
read -r -p "registry user: " U
read -r -s -p "password: " PW; echo
R="https://$ADDR:5443/v2/$NAME"
ACCEPT="application/vnd.oci.image.index.v1+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json, application/vnd.docker.distribution.manifest.list.v2+json"
# the password goes to curl on its input, not on the command line (where ps would show it)
c() { printf 'user = "%s:%s"\n' "$U" "$PW" | curl -s -K - --noproxy "$ADDR" --cacert caddy-root.crt -H "Accept: $ACCEPT" "$@"; }

DIG=$(c -I "$R/manifests/$VER" | tr -d '\r' | awk -F': ' 'tolower($1)=="docker-content-digest"{print $2}')
[ -n "$DIG" ] || { echo "$NAME:$VER is not in the registry, or the user / password is wrong"; exit 1; }
PARTS=$(c "$R/manifests/$VER" | python3 -c "import json, sys; [print(m['digest']) for m in json.load(sys.stdin).get('manifests', [])]")
for d in $PARTS $DIG; do          # its parts first, then the version itself
  code=$(c -o /dev/null -w '%{http_code}' -X DELETE "$R/manifests/$d")
  [ "$code" = "202" ] || { echo "deleting ${d:0:19} answered HTTP $code - stopped here"; exit 1; }
done
echo "$NAME:$VER deleted. Freeing the space only it used - the registry stops for this:"
docker compose stop registry >/dev/null 2>&1
N=$(docker compose run --rm -T registry garbage-collect /etc/docker/registry/config.yml 2>&1 | grep -c "eligible for deletion")
docker compose start registry >/dev/null 2>&1
echo "  $N files freed; the registry runs again. What is left: https://$ADDR:5443/v2/$NAME/tags/list"
