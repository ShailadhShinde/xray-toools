# dev-pipeline - the files for DEV_PIPELINE.md

| File | Where it goes | What it is |
|---|---|---|
| `compose.dev.yml` | each project folder, next to `Dockerfile.naive` | the developer's compose file: the code mounted live, a restart instead of a build (DEV_PIPELINE.md section 2) |
| `registry/compose.yml` | the Linux server that keeps the images | Docker's registry behind Caddy: HTTPS on port 5443, a password per person (section 5) |
| `registry/Caddyfile` | next to it | the address, the certificate, the users (a name and a password hash each) |
| `registry/.env.example` | next to it, copied to `.env` | the server's address, the images' folder |
| `registry/delete-version.sh` | next to it | deletes one old version and frees the space only it used (section 5.5) |

The release itself is `xray_release.py` in the tools folder (section 6).
