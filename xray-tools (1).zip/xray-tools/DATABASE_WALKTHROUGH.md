# Database Walkthrough

Your programs used to run on the PC and write into the MySQL you open with MySQL Workbench. Running in containers, their rows did not show up there. This page explains why, then gives the two ways that work, step by step with the output of each step: keep the database on your PC (part 1), or put it in a container next to your programs (part 2 for MySQL, part 3 for PostgreSQL). Part 4 builds a database image of your own. After that, the client walkthrough.

<form class="fill" id="fill" autocomplete="off">
<p class="fill-head"><strong>Your values</strong> <span>Type them once: every command on this page uses them. They stay in this browser.</span></p>
<label for="f-site">Your system's folder<input id="f-site" data-root data-token="D:\suite\site" value="D:\suite\site" spellcheck="false"></label>
<label for="f-dbname">Your database's name<input id="f-dbname" data-token="DBNAME" value="suite" spellcheck="false"></label>
<label for="f-mysqlbin">MySQL's bin folder on the PC<input id="f-mysqlbin" data-token="C:\Program Files\MySQL\MySQL Server 8.0\bin" value="C:\Program Files\MySQL\MySQL Server 8.0\bin" spellcheck="false"></label>
<button type="reset">Back to the examples</button>
</form>

*Tested* on Ubuntu 24.04 with Docker 29, MySQL 8.4 and PostgreSQL 17. "Your PC's database" was played by a MySQL on the test machine, set up like a Windows install: root may log in from that machine only. The rest of the test system was three test programs (detector, hub, worker) and an ASP.NET dashboard image. The outputs below come from those runs, with the folders written as this page's Windows examples. Not tested here: Windows itself, MySQL Workbench and pgAdmin. Their clicks are described; the same connections were tested with the command-line clients.

---

## 0. Where the rows go, and why you did not see them

```text
 YOUR PC
 MySQL, installed (port 3306)  <---  Workbench: your usual connection ("Local instance")
      ^          ^
      |          +-- the programs, when they ran on the PC itself: "localhost"
      |
      +-- a program in a container: "host.docker.internal" (in a container, "localhost" is the container itself)

 DOCKER
 hub, dashboard ...  --->  db: a MySQL in a container, with data of its own  <---  Workbench: 127.0.0.1, port 3307
```

The usual reasons:

| What happened | Why | The fix |
|---|---|---|
| a program's setting says `localhost` or `127.0.0.1` | inside a container that is the container itself, where no MySQL runs | `host.docker.internal` (step 4) |
| MySQL answers `Host '172.17.0.1' is not allowed` or `Access denied for user 'root'@'172.17.0.1'` | root may log in from the PC itself only, and to MySQL a container is another machine | a user for the programs (step 3) |
| the program writes to `db`, a MySQL in a container | that is another database: Workbench still shows your PC's | a second Workbench connection (step 11), or point the program to your PC's (part 1) |
| the rows are there, but you see the old ones | Workbench shows what it read when the query ran; a dashboard may read another database, or times can be 5:30 hours off | run the query again; EMPTY_DASHBOARD.md |

## 1. Which database does each program use? (1 minute)

```bat
cd /d D:\suite\site
docker compose exec hub env | findstr "DB_HOST DB_PORT DB_USER DB_NAME"
```

```text
DB_HOST=host.docker.internal
DB_PORT=3306
DB_USER=app
```

Your programs may use other names for these settings. Look for the host, port and user lines. Do not paste the whole `env` output anywhere: it shows the passwords too.

| The host | The database | Look into it with |
|---|---|---|
| `host.docker.internal` | the MySQL on your PC | Workbench, your usual connection (port 3306) |
| `db` | a MySQL in a container of this system | Workbench, a second connection: 127.0.0.1, port 3307 (step 11) |
| `localhost`, `127.0.0.1` | nothing: in a container, that is the container itself | step 4 |
| another address (`192.168...`) | a MySQL on another machine | Workbench, with that address |

The dashboard's database is in its connection string (`Server=...`), in `compose.yml` or `.env`.

---

## 2. Part 1: keep the database on your PC. Is MySQL listening? (1 minute)

Your data stays where it is, and Workbench stays as it is. Only the way in changes.

```bat
netstat -ano | findstr ":3306"
```

A line like this one means MySQL takes connections on every address of the PC, which includes Docker's:

```text
  TCP    0.0.0.0:3306           0.0.0.0:0              LISTENING       4567
```

If the only line says `127.0.0.1:3306` and the test in step 5 times out, MySQL takes connections from this PC's own programs only. Change `bind-address` in MySQL's `my.ini` (this needs an administrator), or use part 2.

## 3. A user for the programs (2 minutes, in Workbench)

Open your usual connection as root and run:

```sql
CREATE USER 'app'@'%' IDENTIFIED BY 'a-long-password-of-your-own';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON suite.* TO 'app'@'%';
SHOW GRANTS FOR 'app'@'%';
```

```text
Grants for app@%
GRANT USAGE ON *.* TO `app`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON `suite`.* TO `app`@`%`
```

- **`'app'@'%'`:** the user `app`, from any address, Docker's included. `root` stays allowed from the PC only, which is safer.
- **`suite.*`:** every table of the database `suite`. Write your database's name there.
- **Programs that make tables themselves:** `GRANT ALL ON suite.* TO 'app'@'%';` instead.
- **An `app` you have already:** `'app'@'localhost'` is another account. Make `'app'@'%'` next to it.

## 4. The programs' settings (2 minutes)

In each program's settings file, for example `D:\suite\site\hub.env`:

```text
DB_HOST=host.docker.internal
DB_PORT=3306
DB_USER=app
DB_PASSWORD=a-long-password-of-your-own
```

The dashboard's connection string, in `compose.yml` or `.env`:

```text
Server=host.docker.internal;Port=3306;Database=suite;Uid=app;Pwd=a-long-password-of-your-own
```

Then, in the system's folder:

```bat
docker compose up -d --wait
```

Only the services whose settings changed restart. On Linux, a service that uses `host.docker.internal` also needs `extra_hosts: ["host.docker.internal:host-gateway"]` in compose.yml. `xray_merge.py` keeps those lines while a setting uses the name.

## 5. Test the way in, from a container (2 minutes)

```bat
docker run --rm -it --add-host host.docker.internal:host-gateway mysql:8.4 mysql -h host.docker.internal -u app -p DBNAME -e "SELECT USER(), DATABASE(), NOW()"
```

It asks `Enter password:`: type the password from step 3. The first time, Docker first downloads `mysql:8.4`.

```text
+----------------+------------+---------------------+
| USER()         | DATABASE() | NOW()               |
+----------------+------------+---------------------+
| app@172.17.0.1 | suite      | 2026-11-23 03:41:43 |
+----------------+------------+---------------------+
```

`172.17.0.1` is the address MySQL saw the container come from; yours may differ. The same messages come from your programs, in their logs, worded the way their library words them:

| You see | Means | Do |
|---|---|---|
| `ERROR 2003 (HY000): Can't connect to MySQL server on '127.0.0.1:3306' (111)` | the setting says 127.0.0.1: the container itself | `host.docker.internal` (step 4) |
| `ERROR 1130 (HY000): Host '172.17.0.1' is not allowed to connect to this MySQL server` | MySQL has no account for other machines at all | step 3 |
| `ERROR 1045 (28000): Access denied for user 'root'@'172.17.0.1' (using password: YES)` | root is for the PC itself | use `app` |
| `ERROR 2005 (HY000): Unknown MySQL server host 'host.docker.internal' (-2)` | Linux, without the extra line | `--add-host host.docker.internal:host-gateway` / `extra_hosts` (step 4) |
| `Can't connect ... (110)`, or it hangs, then times out | Windows' firewall, or MySQL listens on 127.0.0.1 only | step 2; the firewall needs an administrator: an inbound rule for TCP 3306 |

## 6. See the rows in Workbench

Your usual connection (port 3306):

```sql
SELECT * FROM results ORDER BY id DESC LIMIT 10;
```

A row a program wrote from a container sits next to the ones written before:

```text
+----+----------------+---------------------+
| id | result         | seen_at             |
+----+----------------+---------------------+
|  3 | FROM-CONTAINER | 2026-11-23 03:41:44 |
|  2 | FROM-PC-2      | 2026-11-23 03:41:08 |
|  1 | FROM-PC-1      | 2026-11-23 03:41:08 |
+----+----------------+---------------------+
```

Workbench shows what it read when the query ran. Run it again to see newer rows. A time 5:30 hours off: EMPTY_DASHBOARD.md, check 3.

---

## 7. Part 2: the database in a container (MySQL). When, and where the files go

Use part 2 for clients (each one gets its own database), for a server, for Linux, or when the PC's MySQL should go. Afterwards:

- **Your data:** it lives in a Docker volume (`suite_dbdata`), no longer in the PC's MySQL.
- **The programs:** they reach the database by the name `db`.
- **Workbench:** it reaches the database at 127.0.0.1, port 3307.
- **The passwords:** they are in the system's `.env`.

```text
D:\suite\site\
  compose.yml          + the db service (xray_merge.py writes it)
  .env                 + DB_ROOT_PASSWORD, DB_PASSWORD
  db\init\             the .sql files the database runs on its FIRST start, in name order
    01-suite.sql       your tables and stored procedures (and your rows): from Workbench, step 9
```

**No Dockerfile is needed.** A database runs from the official image (`mysql:8.4`), with settings in compose.yml and your tables in `db\init`. Part 4 shows an image of your own, for when the tables should travel inside the image.

## 8. Let the merge add the database (1 minute)

First stop the programs, so that nothing writes into the PC's database between your export (step 9) and the switch (step 10):

```bat
cd /d D:\suite\site
docker compose stop
```

Then run the command you used for the one file (ONE_SYSTEM_WALKTHROUGH.md, step 3), with `--db mysql --force` added:

```bat
cd /d D:\xray-tools
python xray_merge.py --name suite --db mysql --force --out D:\suite\site ^
  runs\detector\plan\compose.combined.yml runs\hub\plan\compose.combined.yml ^
  runs\worker\plan\compose.combined.yml D:\dashboard\docker\compose.yml ^
  --rename web=dashboard
```

`--force` writes the folder's compose.yml, .env and settings files again, so edits you made in them are gone. Your `data` folder stays. When the folder's `.env` already has database passwords, they are kept: a database keeps the passwords of its first start.

You should see these lines:

```text
xray_merge 0.2.0: 4 compose file(s) -> ONE: D:\suite\site\compose.yml   (project suite)

SERVICES
  db         mysql:${MYSQL_VERSION:-8.4}   the system's own MySQL (--db mysql)
  ...

ADDRESSES - a service reaches another by its name and the port INSIDE that container
  hub        DB_HOST: host.docker.internal  ->  db   (hub.env)
  worker     HUB_URL: http://host.docker.internal:5014/check  ->  http://hub:5014/check   (worker.env)
  dashboard  ConnectionStrings__Main: Server=host.docker.internal;Port=3306;Database=suite;Uid=app;Pwd=***  ->  Server=db;Port=3306;Database=suite;Uid=app;Pwd=***   (.env ConnectionStrings__Main)
  hub        DB_PASSWORD: hub.env -> compose.yml as ${DB_PASSWORD} (the new database's password)
  dashboard  ConnectionStrings__Main: in compose.yml now (was ${ConnectionStrings__Main} in .env), its password from .env

START ORDER
  ...
  hub starts after db is healthy
  dashboard starts after db is healthy

THE DATABASE (--db mysql)
  db: MySQL 8.4 - database suite, user app (password DB_PASSWORD) and root (password DB_ROOT_PASSWORD), both made new, in .env
  On its first start it runs the .sql files of ./db/init, and holds only what they make: your tables
  (01-schema.sql), and your rows too if the file has them. Your current database is not changed.
  To look into it from this PC (MySQL Workbench): 127.0.0.1, port 3307, user app, its password from .env
  Its clock: TZ=IST-5:30, from the programs' settings
  uses it: hub, dashboard
```

The database's part of `compose.yml`, line by line:

```text
  db:
    image: "mysql:${MYSQL_VERSION:-8.4}"
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: "${DB_ROOT_PASSWORD:?DB_ROOT_PASSWORD is missing in .env}"
      MYSQL_DATABASE: suite
      MYSQL_USER: app
      MYSQL_PASSWORD: "${DB_PASSWORD:?DB_PASSWORD is missing in .env}"
      TZ: "IST-5:30"
    volumes:
      - "dbdata:/var/lib/mysql"
      - "./db/init:/docker-entrypoint-initdb.d:ro"
    ports:
      - "127.0.0.1:3307:3306"
    healthcheck:
      test:
        - CMD-SHELL
        - "mysqladmin ping -h 127.0.0.1 -uroot -p\"$$MYSQL_ROOT_PASSWORD\" --silent"
      interval: 5s
      timeout: 3s
      retries: 30
      start_period: 60s
```

| Line | Means |
|---|---|
| `image: mysql:8.4` | the official MySQL; the version is a line in `.env` |
| `MYSQL_ROOT_PASSWORD`, `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD` | root's password, the database, and the programs' user with its password. They are used once, on the first start. Later changes in `.env` do not reach the database |
| `TZ` | the database's clock, the same as your programs'. Without it, `NOW()` gives UTC, 5:30 hours off in India |
| `dbdata:/var/lib/mysql` | the data, in a Docker volume (`suite_dbdata`). It stays through `down` and restarts |
| `./db/init:/docker-entrypoint-initdb.d:ro` | the folder with your .sql files, run on the first start only |
| `127.0.0.1:3307:3306` | Workbench on this PC reaches it at 127.0.0.1, port 3307. Port 3306 belongs to your PC's own MySQL; `127.0.0.1` keeps other PCs out |
| `healthcheck` | it is healthy once MySQL answers; the programs that use it wait for that |

The programs' settings now point to `db`. In `hub.env`:

```text
# xray_merge.py: was host.docker.internal
DB_HOST=db
# DB_PASSWORD: in compose.yml now - ${DB_PASSWORD}, the database's password, written once in .env
DB_PORT=3306
DB_USER=app
```

`DB_PORT` stays 3306: that is the port inside the network. 3307 is only for Workbench on this PC.

## 9. Your tables (and rows) into db\init (5 minutes)

**In Workbench,** with your usual connection:

1. Server > Data Export.
2. Tick your database (`suite`).
3. Below the list, choose **Dump Structure and Data**. Your site's rows then move into the container too. For the master copy that clients get, choose **Dump Structure Only**.
4. Tick **Dump Stored Procedures and Functions**, **Dump Events** and **Dump Triggers**.
5. Choose **Export to Self-Contained File**: `D:\suite\site\db\init\01-suite.sql`.
6. Tick **Include Create Schema**.
7. Click **Start Export**.

**Or with MySQL's own mysqldump, in CMD on the PC** (it logs in as root, from the PC itself):

```bat
cd /d D:\suite\site
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe" -u root -p --routines --triggers --single-transaction --databases DBNAME --result-file=db\init\01-suite.sql
```

For structure only, add `--no-data`. The folder `bin` is where your MySQL Server is installed (8.0, 8.4 ...).

Check the file:

```bat
findstr /n "CREATE INSERT DEFINER" db\init\01-suite.sql
```

```text
22:CREATE DATABASE /*!32312 IF NOT EXISTS*/ `suite` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
33:CREATE TABLE `results` (
47:INSERT INTO `results` VALUES (1,'FROM-PC-1','2026-11-23 03:41:08'),(2,'FROM-PC-2','2026-11-23 03:41:08'),(3,'FROM-CONTAINER','2026-11-23 03:41:44');
64:CREATE DEFINER=`root`@`localhost` PROCEDURE `add_result`(IN r VARCHAR(20))
```

A stored procedure runs as its `DEFINER`, so that user must exist in the new database. `root`@`localhost` and the programs' user (`app`@`%`) do. Any other user: replace it in the file with `root`@`localhost`.

## 10. Start it (1 minute)

```bat
docker compose config -q
docker compose up -d --wait
```

```text
 Volume suite_dbdata Created
 Container suite-db-1 Created
 Container suite-hub-1 Recreate
 Container suite-dashboard-1 Recreate
 Container suite-db-1 Started
 Container suite-db-1 Waiting
 Container suite-detector-1 Healthy
 Container suite-db-1 Healthy
 Container suite-hub-1 Started
 ...
 Container suite-worker-1 Healthy
```

The first start of a new database takes longer, about 20 seconds in the test. MySQL makes the database, runs your file, then restarts.

```bat
docker compose ps --format "table {{.Service}}\t{{.Status}}\t{{.Ports}}"
docker compose logs db | findstr /c:"initdb.d"
```

```text
SERVICE     STATUS                    PORTS
dashboard   Up 6 seconds              0.0.0.0:8090->8080/tcp
db          Up 17 seconds (healthy)   33060/tcp, 127.0.0.1:3307->3306/tcp
detector    Up 17 seconds (healthy)   0.0.0.0:5011->5011/tcp
hub         Up 6 seconds (healthy)    0.0.0.0:5014->5014/tcp
worker      Up Less than a second

db-1  | 2026-11-23 09:20:55+05:30 [Note] [Entrypoint]: /usr/local/bin/docker-entrypoint.sh: running /docker-entrypoint-initdb.d/01-suite.sql
db-1  | 2026-11-23 09:20:55+05:30 [Warn] [Entrypoint]: /usr/local/bin/docker-entrypoint.sh: ignoring /docker-entrypoint-initdb.d/README.txt
```

## 11. Open it in Workbench (2 minutes)

1. On Workbench's home screen, click **+** next to "MySQL Connections".
2. Connection Name: `suite in Docker`.
3. Hostname `127.0.0.1`, Port `3307`, Username `app`.
4. Password: **Store in Vault**, then paste `DB_PASSWORD` from `D:\suite\site\.env`.
5. Click **Test Connection**, then **OK**.

Open the new connection and run:

```sql
SELECT * FROM results;
SELECT NOW(), UTC_TIMESTAMP(), @@system_time_zone;
```

```text
+----+----------------+---------------------+
| id | result         | seen_at             |
+----+----------------+---------------------+
|  1 | FROM-PC-1      | 2026-11-23 03:41:08 |
|  2 | FROM-PC-2      | 2026-11-23 03:41:08 |
|  3 | FROM-CONTAINER | 2026-11-23 03:41:44 |
+----+----------------+---------------------+
+---------------------+---------------------+--------------------+
| NOW()               | UTC_TIMESTAMP()     | @@system_time_zone |
+---------------------+---------------------+--------------------+
| 2026-11-23 09:13:42 | 2026-11-23 03:43:42 | IST                |
+---------------------+---------------------+--------------------+
```

Your rows came along, and `NOW()` gives your own time. You now have two connections:

| Connection | Port | The database |
|---|---|---|
| your usual one ("Local instance") | 3306 | the MySQL on your PC: the old data, which nothing writes to any more |
| `suite in Docker` | 3307 | the system's database, which the programs write to now |

## 12. The programs write there now

```bat
docker compose exec hub env | findstr "DB_HOST"
```

```text
DB_HOST=db
```

A row that a program of the system wrote, seen in the `suite in Docker` connection:

```text
+----+----------------+---------------------+
| id | result         | seen_at             |
+----+----------------+---------------------+
|  4 | FROM-SYSTEM    | 2026-11-23 09:13:42 |
|  3 | FROM-CONTAINER | 2026-11-23 03:41:44 |
+----+----------------+---------------------+
```

The new row has your own time. The old rows keep the times they were written with.

## 13. Backups, and the rules

In CMD, in the system's folder:

```bat
docker compose exec -T db sh -c "MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysqldump -uroot --routines --triggers --single-transaction --databases DBNAME" > backup-DBNAME.sql
```

The file holds everything, tables and rows. To put it back:

```bat
docker compose exec -T db sh -c "MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysql -uroot" < backup-DBNAME.sql
```

In the test, a deleted table came back with all its rows. Run both in CMD, not PowerShell: PowerShell has no `<`, and its `>` writes a file MySQL cannot read. Workbench's Data Export and Data Import, on the `suite in Docker` connection, do the same by clicking.

The rules:

- **Once, on the first start:** the passwords in `.env` and the files in `db\init`. Changing them later does not change the database.
- **The data stays:** `docker compose down` and restarts keep it (*tested*).
- **`docker compose down -v` DELETES it,** with the volume. Use it only for a test database.
- **A change of your tables later:** make it in Workbench (`ALTER TABLE ...`) on the `suite in Docker` connection. Put the same change into `db\init\01-suite.sql` too, so that new clients get it.
- **One folder, one project name:** two folders with the same `--name` share their containers and their database. `xray_merge.py` refuses a name that another folder already uses.
- **Your PC's MySQL:** keep it as the old copy, or stop its Windows service once you trust the new one.

---

## 14. Part 3: PostgreSQL in a container. The same, with other names

Use part 3 instead of part 2 when your programs use PostgreSQL. Do not do part 2 first in the same folder: the PostgreSQL would find MySQL's files in the database volume.

| | MySQL | PostgreSQL |
|---|---|---|
| `--db` | `mysql` | `postgres` |
| image | `mysql:8.4` | `postgres:17` |
| port inside the network | 3306 | 5432 |
| port on this PC (for your tool) | 3307 | 5433 |
| your tool | MySQL Workbench | pgAdmin or DBeaver |
| users | `root` + the programs' user (`app`) | the programs' user is the database's owner, with full rights (no root) |
| passwords in `.env` | `DB_ROOT_PASSWORD`, `DB_PASSWORD` | `DB_PASSWORD` |
| export | Workbench Data Export, `mysqldump` | pgAdmin Backup, `pg_dump` |
| a program's settings | `DB_HOST=db`, `DB_PORT=3306` | `DB_HOST=db`, `DB_PORT=5432` |
| .NET connection string | `Server=db;Port=3306;Database=suite;Uid=app;Pwd=...` | `Host=db;Port=5432;Database=suite;Username=app;Password=...` (Npgsql) |
| Python | PyMySQL, mysql-connector | psycopg |

## 15. Let the merge add a PostgreSQL (1 minute)

```bat
cd /d D:\suite\site
docker compose stop
cd /d D:\xray-tools
python xray_merge.py --name suite --db postgres --force --out D:\suite\site ^
  runs\detector\plan\compose.combined.yml runs\hub\plan\compose.combined.yml ^
  runs\worker\plan\compose.combined.yml D:\dashboard\docker\compose.yml ^
  --rename web=dashboard
```

The new lines, with programs whose settings pointed to a PostgreSQL on the PC (port 5432):

```text
ADDRESSES - a service reaches another by its name and the port INSIDE that container
  hub        DB_HOST: host.docker.internal  ->  db   (hub.env)
  dashboard  ConnectionStrings__Main: Host=host.docker.internal;Port=5432;Database=suite;Username=app;Password=***  ->  Host=db;Port=5432;Database=suite;Username=app;Password=***   (.env ConnectionStrings__Main)
  hub        DB_PASSWORD: hub.env -> compose.yml as ${DB_PASSWORD} (the new database's password)

THE DATABASE (--db postgres)
  db: PostgreSQL 17 - database suite, user app (password DB_PASSWORD), made new, in .env
  ...
  To look into it from this PC (pgAdmin or DBeaver): 127.0.0.1, port 5433, user app, its password from .env
  Its clock: TZ=IST-5:30, from the programs' settings
  uses it: hub, dashboard
```

The database's part of `compose.yml`:

```text
  db:
    image: "postgres:${POSTGRES_VERSION:-17}"
    restart: unless-stopped
    environment:
      POSTGRES_DB: suite
      POSTGRES_USER: app
      POSTGRES_PASSWORD: "${DB_PASSWORD:?DB_PASSWORD is missing in .env}"
      TZ: "IST-5:30"
    volumes:
      - "dbdata:/var/lib/postgresql/data"
      - "./db/init:/docker-entrypoint-initdb.d:ro"
    ports:
      - "127.0.0.1:5433:5432"
    healthcheck:
      test:
        - CMD-SHELL
        - "pg_isready -h 127.0.0.1 -U \"$$POSTGRES_USER\" -d \"$$POSTGRES_DB\""
      ...
```

`pg_isready -h 127.0.0.1` reports healthy only once the first-start scripts are done, so the programs never meet a half-made database.

## 16. Your tables into db\init (5 minutes)

**In pgAdmin:**

1. Right-click your database > Backup...
2. Filename: `D:\suite\site\db\init\01-suite.sql`. Format: **Plain**.
3. In Data Options, under "Do not save", switch on **Owner** and **Privileges**. For the master copy that clients get, also switch on **Only schema**.
4. Click **Backup**.

**Or with pg_dump,** from a container (it asks for the password of the `postgres` user):

```bat
cd /d D:\suite\site
docker run --rm -it -v "%cd%\db\init:/out" --add-host host.docker.internal:host-gateway postgres:17 pg_dump -h host.docker.internal -U postgres --no-owner --no-privileges -f /out/01-suite.sql DBNAME
```

For structure only, add `--schema-only`. Use the same major version as your PostgreSQL (`postgres:16` for a 16). An older pg_dump refuses a newer server.

```text
26:CREATE PROCEDURE public.add_result(IN r character varying)
39:CREATE TABLE public.results (
77:COPY public.results (id, result, seen_at) FROM stdin;
87:SELECT pg_catalog.setval('public.results_id_seq', 2, true);
```

`--no-owner` (and "Owner" in pgAdmin): the tables then belong to the programs' user in the new database, whatever role owned them before.

## 17. Start it, and open it (3 minutes)

```bat
docker compose up -d --wait
docker compose logs db | findstr "initdb.d complete"
```

```text
db-1  | /usr/local/bin/docker-entrypoint.sh: running /docker-entrypoint-initdb.d/01-suite.sql
db-1  | PostgreSQL init process complete; ready for start up.
```

In pgAdmin:

1. Right-click Servers > Register > Server.
2. Name: `suite in Docker`.
3. Connection: host `127.0.0.1`, port `5433`, maintenance database `suite`, user `app`, password: `DB_PASSWORD` from `.env`.

DBeaver takes the same values. The same check from the command line:

```text
 id |  result   |             seen_at
----+-----------+----------------------------------
  1 | FROM-PC-1 | 2026-11-23 09:14:41.34899+05:30
  2 | FROM-PC-2 | 2026-11-23 09:14:41.349884+05:30

 TimeZone
----------
 IST-5:30
```

A shell in the database itself: `docker compose exec db psql -U app -d suite`, then `\dt` lists the tables.

```text
        List of relations
 Schema |  Name   | Type  | Owner
--------+---------+-------+-------
 public | results | table | app
```

## 18. PostgreSQL: backups, and the programs' settings

```bat
docker compose exec -T db pg_dump -U app -d DBNAME --no-owner --clean --if-exists > backup-DBNAME.sql
docker compose exec -T db psql -q -U app -d DBNAME < backup-DBNAME.sql
```

The second line puts a backup back. `--clean` makes it drop each table first, so afterwards the rows are exactly those of the backup (*tested*: rows deleted after the backup were back). After `docker compose down` and `up`, the log says `PostgreSQL Database directory appears to contain a database; Skipping initialization`, and the data is still there (*tested*).

A program in the system connects with:

- **Python (psycopg):** host `db`, port `5432`, database `suite`, user `app`, password from `DB_PASSWORD`.
- **.NET (Npgsql):** `Host=db;Port=5432;Database=suite;Username=app;Password=${DB_PASSWORD}`, the way `xray_merge.py` writes it.

---

## 19. Part 4: a database image of your own (the Dockerfile)

You need one only when the tables should travel inside the image, for example to a client's site where you start the database without a `db\init` folder. In a new folder, next to an `init` folder with your `01-schema.sql`:

```text
# Dockerfile - the official MySQL + your tables, made on its first start
FROM mysql:8.4
COPY init/ /docker-entrypoint-initdb.d/
```

```bat
docker build -t suite-db:1.0 .
```

In compose.yml, replace `image: mysql:8.4` with `image: suite-db:1.0` and remove the `./db/init` line. In the test, a new database from this image had the table and the stored procedure. The image is the size of `mysql:8.4` (about 1 GB) plus your file. The passwords are not in the image: they still come from `.env` when it starts. For PostgreSQL the same, with `FROM postgres:17`.

## 20. When something is wrong

| You see | Do |
|---|---|
| `Bind for 0.0.0.0:3306 failed: port is already allocated` | the database container wants port 3306 of the PC, which your PC's MySQL has. Use 3307: `127.0.0.1:3307:3306` (the merge does) |
| `dependency failed to start: container suite-db-1 is unhealthy` | `docker compose logs db` shows why. Often a .sql file in `db\init` that fails: fix it, then make the database again with `docker compose down -v` (test data only) and `up -d --wait` |
| your .sql files did not run | they run on the first start of an empty database only. The log line `running /docker-entrypoint-initdb.d/...` shows they did |
| the programs log `Access denied` after a new `.env` | the database keeps the passwords of its first start. Put the old passwords back into `.env` (the merge keeps them with `--force`) |
| `a compose project named suite runs already, from ...` | two folders with one name would share containers and the database. Use another `--name` |
| a PostgreSQL that keeps restarting after a change of `--db` | its volume holds the other database's files. A new name, or `docker compose down -v` (test data only) |
| times 5:30 hours off | `TZ` under the db service's `environment` (step 8) |
| anything about the PC's database | the table in step 5 |

## 21. Next: the clients

Your system now has its own database. For clients, follow ONE_SYSTEM_WALKTHROUGH.md part B (steps 9-12, the master copy) and part C (the clients). The master copy uses `--db mysql` (or `--db postgres`) the same way, with **Dump Structure Only** in step 9: clients start without your rows. Each client then gets its own database, password and volume. The client tool leaves out the port 3307 / 5433: a client's database is reachable inside its own network only.

## 22. On Ubuntu

| Windows (this page) | Ubuntu |
|---|---|
| D:\suite\site | `/home/you/suite/site` |
| cd /d FOLDER | `cd FOLDER` |
| python | `python3` |
| netstat -ano piped to findstr ":3306" | `ss -ltn` piped to `grep ":3306"` |
| findstr "A B" (A or B), findstr /c:"A" | `grep -E "A|B"`, `grep "A"` |
| the PC's mysqldump.exe | `mysqldump` (Ubuntu's MySQL package; `sudo mysqldump` when root logs in through the system) |
| docker run ... -v "%cd%\db\init:/out" | `docker run ... --user "$(id -u):$(id -g)" -v "$PWD/db/init:/out"` (the file is then yours, not root's) |
| sh -c "...$MYSQL_ROOT_PASSWORD..." | `sh -c '...$MYSQL_ROOT_PASSWORD...'`: single quotes, or the PC's shell fills in its own (empty) value |

Type Linux folders (starting with `/`) under Your values, and the commands on this page are shown in their Ubuntu form. A MySQL installed on Ubuntu listens on 127.0.0.1 only. For part 1, that means `bind-address` in `/etc/mysql/mysql.conf.d/mysqld.cnf` and a firewall rule; part 2 is simpler there.
