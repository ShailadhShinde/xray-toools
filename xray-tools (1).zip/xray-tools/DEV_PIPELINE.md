# Developer pipeline: from a code change to a tested image, every day

How a team works with X-Ray day to day. Developers change code and hand over test images in minutes. A tester runs
them. One person makes the release, the small verified image for production. Nobody waits for X-Ray's optimisation
while developing.

In the tools folder for this:
- `dev-pipeline/compose.dev.yml`: the developer's compose file, the code mounted live
- `dev-pipeline/registry/`: the office's image registry (Docker's registry behind Caddy: HTTPS and a password),
  with `delete-version.sh` for old versions
- `xray_release.py`: one release, every X-Ray step in a row, stops at the first failure, ends with the version tag

*Tested* on Ubuntu 24.04 with Docker 29 (test projects, a CPU program and a small web server), unless a line says
otherwise. Not tested here: a GPU, Windows, Docker Scout, Gitleaks, the network scanners.

---

## 0. The picture

```
 the developer's PC                     the office server                  production
 code + Dockerfile.naive                registry: every image, every version   compose.yml + .env
   |  compose.dev.yml: change the code,     ^             |                       ^
   |  restart - seconds, no build           | push        | pull                  | pull NAME-slim:1.4.0
   v                                        |             v                       |
 test image  NAME:1.4.0-rc1  --------------+        the tester runs it  -- OK --> the release: xray_release.py
 (Dockerfile.naive, the code inside)                (the same compose,         every X-Ray step, VERDICT: PASS
                                                     a test .env)               -> NAME-slim:1.4.0, pushed
```

Two images per project:

| | The test image | The release image |
|---|---|---|
| made by | each developer, any time | one person, when a version is ready |
| from | `Dockerfile.naive` (everything in `requirements.txt` installed) | X-Ray's plan: only what the program really used |
| how long | seconds after a code change | the X-Ray steps: minutes (a GPU project: longer, mostly the builds) |
| size | does not matter | small |
| name | `NAME:1.4.0-rc1`, `-rc2` ... | `NAME-slim:1.4.0` |
| used by | developers, the tester | production |

The release is made from the exact version the tester approved. Its `verify.txt` must say the slim image did
everything the test image did.

---

## 1. What each project's repository holds

```text
src/ or *.py                    the code
requirements.txt                exact versions (==), from the developer's working venv
.python-version                 the Python the developer uses (3.11) - xray_naive.py reads it
Dockerfile.naive                written by xray_naive.py - committed: everyone builds the same image
Dockerfile.naive.dockerignore   written with it (keeps .git, venvs, logs and every .env out of the image)
requirements.docker.txt         written with it (what the build installs)
compose.dev.yml                 from dev-pipeline/ (section 2)
.env.example                    the names of the settings, no passwords
```

Never in the repository: `.env` (the passwords and addresses of one PC). Add to the project's `.gitignore`:

```text
.env
.env.*
!.env.example
```

---

## 2. The developer's loop

### 2.1 Once per project: Dockerfile.naive

The developer writes it once, and again only when `requirements.txt` changes (GUIDE 3b; on Linux with the venv's
Python, LINUX_GUIDE 1):

```bat
cd C:\Users\me\xray-tools
python xray_naive.py --project C:\code\app --requirements requirements.txt --entry main.py --name app --gpu
copy runs\app\naive\Dockerfile.naive* C:\code\app\
copy runs\app\naive\requirements.docker.txt C:\code\app\
```

`--gpu` for a program that uses an NVIDIA GPU, `--cpu` otherwise. Then commit the three files.

### 2.2 compose.dev.yml

Copy `dev-pipeline\compose.dev.yml` into the project, next to `Dockerfile.naive`, and change the lines marked
`yours`: the name, the port, the data folders. A GPU program: remove the `#` of the GPU lines. Docker Desktop with
WSL 2 gives containers the NVIDIA GPU on Windows (not tested here: no GPU).

What it does:
- builds the image from `Dockerfile.naive`, everything installed
- **mounts the project folder over the code in the image**: the container runs the code of the PC, as it is now
- reads `.env` of the project folder (copy `.env.example` to `.env`, fill in this PC's values)
- `init: true`: restart and stop reach the program at once. *Tested*: a restart took 0.3 s; without it, 10.3 s.
  Docker waited 10 s, then killed the program, because a program that is the container's first process does not
  stop on Docker's signal unless its code handles it

```bat
docker compose -f compose.dev.yml up -d --build
docker compose -f compose.dev.yml logs -f
```

### 2.3 Every day

| What changed | Do | How long (*tested*, the small test project) |
|---|---|---|
| code | `docker compose -f compose.dev.yml restart` | 0.3 s: no build, the mounted code is the new code |
| a library (`requirements.txt`) | `xray_naive.py` again (2.1), then `docker compose -f compose.dev.yml up -d --build` | only the pip step and what follows are built again. pip's downloads are kept between builds (`--mount=type=cache`) |
| a system package, the Python version, the GPU base | `xray_naive.py` again, or edit `Dockerfile.naive`; `up -d --build` | the longest: most layers again |

Docker rebuilds only from the first line of the Dockerfile that changed. `Dockerfile.naive` installs first and copies
the code last, so a code change never reinstalls anything.

---

## 3. Rules for the code

The frameworks stay as they are (Flask, FastAPI, PyTorch, OpenCV ...). These habits make the same code run on a
developer's PC, in the tester's container and in production without a change:

| Rule | Why | Example |
|---|---|---|
| every setting from an env var, with a default | the same code everywhere; only `.env` differs | `DB_HOST = os.getenv("DB_HOST", "localhost")` |
| no `C:\` paths; relative paths or env vars, joined with `os.path.join` | a container is Linux | `os.path.join(os.getenv("DATA_DIR", "data"), "model.onnx")` |
| a server listens on `0.0.0.0` | `127.0.0.1` in a container can be reached from nowhere else | `app.run(host="0.0.0.0", port=5000)` |
| exact versions in `requirements.txt` | the image installs what the developer tested | `numpy==1.26.4`; Windows-only: `pywin32==306; sys_platform == "win32"` |
| `.python-version` with the developer's Python | xray_naive.py builds for it | `3.11` |
| output to the screen (print, logging) | `docker compose logs` shows it | `logging.basicConfig(level=logging.INFO)` |
| no passwords in code or images | images are handed around | `.env`, never committed; X-Ray keeps it out of every image |
| what the program writes: one folder, from an env var | it is mounted, and kept | `OUT_DIR = os.getenv("OUT_DIR", "output")` |
| no `cv2.imshow` without a setting | a container has no screen | `if os.getenv("SHOW", "0") == "1": cv2.imshow(...)` |
| stop cleanly on Ctrl+C | X-Ray's compose files stop the program with Ctrl+C (`stop_signal: SIGINT`); its `finally` blocks run | `try: serve() finally: save_results()` |
| a version for every image, never only `latest` | everyone knows what runs where | `app:1.4.0-rc1`, `app-slim:1.4.0` |

*Tested*: a server with a `finally` block, stopped by `docker compose stop` with X-Ray's compose file. It printed its
"saved" line and stopped in 0.4 s.

---

## 4. Handing a test image to the tester

```bat
cd C:\code\app
docker build -f Dockerfile.naive -t 192.168.1.50:5443/app:1.4.0-rc1 .
docker push 192.168.1.50:5443/app:1.4.0-rc1
```

- **The name**: the registry's address (section 5), the project, the version with `-rc1`, `-rc2` ... for each
  attempt.
- **The code is inside**: unlike `compose.dev.yml`, this image carries the code. *Tested*: after a code change the
  build took 0.3 s, and the project's `.env` was not in the image.
- **Without a registry**: `docker save app:1.4.0-rc1 -o app-rc1.tar`, copy the file, `docker load -i app-rc1.tar`.
  Every version is the whole image again, 5-15 GB for a GPU image. The registry sends only what changed.

**The tester** runs it with the same compose file the program will have in production (or `compose.dev.yml`
without the code mount), a test `.env`, and the test data. Then tells the developer: `1.4.0-rc2 works`.

---

## 5. The office registry

A registry keeps images by name and version: developers push, servers pull. Docker's own registry, behind Caddy for
HTTPS and a password per person, on the Linux server that keeps the images. It stays on the office network: port 5443
is not opened to the internet.

### 5.1 Set it up (once, on the server)

```bash
cp -r dev-pipeline/registry ~/registry && cd ~/registry
cp .env.example .env && nano .env                  # REGISTRY_ADDRESS: the server's name or IP address
docker run --rm caddy:2 caddy hash-password --plaintext "A PASSWORD"     # prints the hash of that password
nano Caddyfile                                     # basic_auth: one line per person, a name and a hash
docker compose up -d
docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt ./caddy-root.crt
```

- **The address**: what every PC types. With an IP address, Caddy's `default_sni` line in the Caddyfile is needed.
  It is already there. *Tested*: without it, `docker login` failed with `remote error: tls: internal error`.
- **caddy-root.crt**: the root of Caddy's own certificate authority. Each PC trusts it once (5.2). It is valid for
  10 years.
- **The images' folder** (`REGISTRY_DATA`, default `./data`): the registry writes it as root. To copy or clean it,
  use `sudo`. In a Proxmox VM, the nightly VM backup covers it.

### 5.2 Each PC: trust the certificate, log in

**A Linux PC or server** (*tested*, no restart needed):

```bash
sudo mkdir -p /etc/docker/certs.d/192.168.1.50:5443
sudo cp caddy-root.crt /etc/docker/certs.d/192.168.1.50:5443/ca.crt
docker login 192.168.1.50:5443
```

**A Windows PC** (Docker Desktop, not tested here): double-click `caddy-root.crt` > Install Certificate > Current
User > Place all certificates in: Trusted Root Certification Authorities > Finish. Then restart Docker Desktop and
`docker login 192.168.1.50:5443`. Docker Desktop takes the trusted roots from Windows. No admin rights are needed for
Current User. If `docker login` still says `x509: certificate signed by unknown authority`: Docker Desktop >
Settings > Docker Engine, add `"insecure-registries": ["192.168.1.50:5443"]`, then Apply & restart. The traffic stays
encrypted, but that PC no longer checks that it talks to your server.

What `docker login` / `docker pull` say (*tested*):

| Message | It means |
|---|---|
| `Login Succeeded` | done: Docker keeps the login for this user |
| `x509: certificate signed by unknown authority` | this PC does not trust caddy-root.crt yet (above) |
| `failed with status: 401 Unauthorized` | wrong user or password |
| `no basic auth credentials` (pull, push) | not logged in on this PC: `docker login 192.168.1.50:5443` |
| `remote error: tls: internal error` | the Caddyfile lacks `default_sni` (the template has it) |
| `dial tcp ... connection refused` | the registry is not running, or port 5443 is closed in a firewall |

### 5.3 Push and pull

```bat
docker push 192.168.1.50:5443/app:1.4.0-rc1
docker pull 192.168.1.50:5443/app:1.4.0-rc1
```

Only what is not there yet travels. *Tested*: after a code change, the next version's push sent 3 small layers. The
other 7 were `Layer already exists`. For a GPU image the base layers (gigabytes) go up once.

What is in it, in a browser or with curl (it asks for the user and password):
`https://192.168.1.50:5443/v2/_catalog` (the images), `https://192.168.1.50:5443/v2/app-slim/tags/list` (the versions).

### 5.4 The registry from a compose file

On a server, the plan's `compose.yml` names the registry's image, and its `build:` lines go (the server builds
nothing). Then `docker compose up -d` pulls it:

```yaml
services:
  app:
    image: 192.168.1.50:5443/app-slim:1.4.0
```

*Tested*: a compose file like that, after `docker login`, pulled the image and ran the program.

### 5.5 Old versions

Each version adds only its changed layers, so the disk fills slowly. To delete a version and free the space only it
used:

```bash
cd ~/registry
bash delete-version.sh app-slim 1.2.0
```

It asks for a registry user and password, deletes that version and its parts, and stops the registry for a minute
while it frees the space. *Tested*: the version kept could still be pulled, complete. Do NOT use the registry's own
`garbage-collect --delete-untagged`: with the images Docker builds today (an index with parts), it also deleted parts
of the version that stayed. That version could no longer be pulled (*tested*).

---

## 6. The release: xray_release.py

For a project that has been through the X-Ray steps once (GUIDE / XRAY_WALKTHROUGH): `runs\NAME\` holds its Step 1
map and its run files. From then on, a release is one command:

```bat
cd C:\Users\me\xray-tools
python xray_release.py --name app --version 1.4.0
python xray_release.py --name app --version 1.4.0 --registry 192.168.1.50:5443 --push
```

On Linux: `python3 xray_release.py ...`. With `--naive` it needs the venv's Python: `~/xray-venv/bin/python`.

Run it on the machine with the test data (and the GPU), from the version the tester approved: the project folder
at that commit.

What it does, in this order, and it stops at the first step that fails:

| Step | What | It stops when |
|---|---|---|
| 1 | Step 1 again (`xray_static.py`, the options of the last time) and `step1-needs.txt` | Step 1 fails |
| 2 | the requirements: `Dockerfile.naive` must be written from today's `requirements.txt` | a line of requirements.txt is not in it: run with `--naive` (xray_naive.py again, the options of the last time, the files copied into the project) |
| 3 | the run files again (`xray_runfile.py`, the options of the last time) | - |
| 4 | build-naive | the build fails (the end of build.log is printed) |
| 5 | run-step2 | the program ended with an error: a release needs a run that works |
| 6 | run-step3-4 | no new plan |
| 7 | build-slim | the build fails |
| 8 | run-slim | verify.txt does not end with `VERDICT: PASS` |
| - | tags `NAME-slim:1.4.0` and `NAME-naive:1.4.0`; with `--registry` also `REGISTRY/NAME-slim:1.4.0`, pushed with `--push` | the push fails (the message says: log in, or trust the certificate) |

**Your settings stay.** The run files are written again for every release, so they follow today's code: a new file
the code reads gets mounted. But the settings you changed at their top (`RUN_SECONDS`, `SOURCE` ...) and your values
in `run.env` are kept, and the output says which: `kept your settings - run-step2.sh: RUN_SECONDS`. A change made
elsewhere in a run file is not kept: put it into those settings or `run.env`, or use `--keep-runfiles`.

**What it leaves**: `runs\NAME\releases\1.4.0.txt`, with `1.4.0.Dockerfile` (the slim image's Dockerfile),
`1.4.0-verify.txt` and `1.4.0.log` (all output) beside it:

```text
X-Ray release 1.1.0 of relapp - 2026-11-17 04:26
  verdict   VERDICT: PASS - the planned image did everything the scenario needs
  project   /home/ubuntu/projects/relapp   git 7f7d9c0
  images    relapp-slim:1.1.0   sha256:b24fc686ac62   180 MB
            relapp-naive:1.1.0   sha256:07f8a37e2f1f   180 MB
  pushed    192.0.2.2:5443/relapp-slim:1.1.0
  tools     xray_static 0.5.22, xray_needs 0.1.18, xray_naive 0.4.14, xray_runfile 0.2.17, xray_trace 0.2.11, ...
  steps     Step 1 (xray_static.py) 0 s, the requirements 0 s, ..., run-slim.sh 1 s, push relapp-slim 1 s
  beside it 1.1.0.Dockerfile (the slim image's Dockerfile), 1.1.0-verify.txt, 1.1.0.log (all output)
  in production: image: 192.0.2.2:5443/relapp-slim:1.1.0
```

(the test release; `192.0.2.2` was the test server's address)

`git ... + uncommitted changes` there means the release was built from files not committed yet. Commit them, so the
version can be found again.

*Tested* (the test projects; they are small, so each release took 5-15 s):
- three releases in a row, one after a code change with a new module. The new file was found by Step 1 and copied
  into the slim image
- a program that crashes: stopped at run-step2 with the program's traceback
- a line added to requirements.txt: stopped at the requirements, telling to add `--naive`
- a Dockerfile.naive that does not build: stopped at build-naive with the end of build.log
- a version given twice: refused (`--again` releases it again)
- the push to the registry, and three older projects whose runs were made by older tool versions

Options: `--project` (the project moved), `--keep-runfiles`, `--skip-requirements-check` (you added a package to
Dockerfile.naive by hand), `--push-naive` (push the test image too), `--again`.

---

## 7. Production

In the plan's `compose.yml` (`runs\NAME\plan\`), or the system's compose file:

```yaml
    image: 192.168.1.50:5443/app-slim:1.4.0
```

```bash
docker compose pull
docker compose up -d
```

- **Back to the version before**: its tag in `image:`, `docker compose up -d` again.
- **A clean stop**: X-Ray's `compose.yml` has `stop_signal: SIGINT` and `stop_grace_period: 30s`. `docker compose
  down`, a restart, or a new version stops the program with Ctrl+C, and it gets 30 s to finish. *Tested*: 0.4 s, and
  the program's `finally` block ran. Without these lines, Docker sends a signal a Python program does not stop on,
  waits 10 s and kills it. A plan made with an older xray_plan: add the two lines under the service.
- **The settings**: the plan's `.env` next to `compose.yml`, one per site. Never in the image.

---

## 8. Security checks before a release

Free tools; run them on the release image before it goes to production. What X-Ray already does:
- the slim image runs as a normal user (uid 1000), not root
- it holds only the files and packages the program used
- `.env` files are kept out of every image
- inputs are mounted read-only
- the plan's compose opens only the ports the program listens on, and a database gets no port at all

| What | Tool | Command | Tested here |
|---|---|---|---|
| known weaknesses in the image's packages (Debian / Ubuntu, Python, .NET) | Trivy | below | yes |
| Python packages, before the build | pip-audit | `pip install pip-audit`, then `pip-audit -r requirements.txt` | yes |
| mistakes in Dockerfiles | Hadolint | `docker run --rm -i hadolint/hadolint:v2.12.0 < Dockerfile` | yes |
| .NET packages | the .NET SDK | `dotnet list package --vulnerable` (in the project folder) | no |
| images, built into Docker Desktop | Docker Scout (a free Docker account) | `docker scout quickview IMAGE`, `docker scout cves IMAGE` | no |
| passwords left in code or git history | Gitleaks | `gitleaks detect` in the repository | no |
| open ports, from another PC | nmap | `nmap -Pn -p- SERVER` (only the proxy's ports and SSH should be open) | no |
| the HTTPS setup | testssl.sh | `testssl.sh https://SERVER` | no |
| a web app or API | OWASP ZAP | `docker run --rm -t zaproxy/zap-stable zap-baseline.py -t https://SERVER` | no |
| the Ubuntu server | Lynis | `sudo apt install lynis`, then `sudo lynis audit system` | no |

### 8.1 Trivy: the image

The scanner gets a saved copy of the image, and no access to Docker itself:

```bat
docker save app-slim:1.4.0 -o app-slim.tar
docker run --rm -v "%CD%:/work" -v trivy-cache:/root/.cache/ aquasec/trivy:0.56.2 image --input /work/app-slim.tar --severity HIGH,CRITICAL --ignore-unfixed
del app-slim.tar
```

On Linux: `-v "$PWD:/work"`, and `rm app-slim.tar`. The first run downloads Trivy's database of known weaknesses
(`trivy-cache` keeps it). If the office's network blocks it (`ghcr.io`), add `--db-repository
mirror.gcr.io/aquasec/trivy-db:2`. *Tested* here: the same scan of a saved image (`trivy image --input`, Trivy
0.56.2 run as a program, since this test machine would not run the scanner's container), with the mirror for the
database (the test machine needed it).

*Tested* on a slim image (python:3.12-slim, Debian 13.7): 50 HIGH, 0 CRITICAL. 47 of them had no fix from Debian
yet; `--ignore-unfixed` showed the 3 that had one. That is normal. What to do:
- **a weakness with a fix in a Debian / Ubuntu package**: build on a fresh base image. `docker pull python:3.12-slim`
  (or the CUDA base) before the release: the slim image is built FROM it
- **a weakness in a Python package**: update its pin in requirements.txt, then a release with `--naive`
- **no fix yet**: nothing to install. Note it and look again at the next release. A slim image has fewer packages,
  so fewer of these

### 8.2 pip-audit: the Python packages

```bat
pip install pip-audit
pip-audit -r requirements.txt
```

*Tested* with `requests==2.25.0`: `Found 13 known vulnerabilities in 3 packages`, each with the version that fixes
it (`requests 2.25.0  PYSEC-2023-74  2.31.0`). It ends with exit code 1 when it finds any, so a script can stop on
it. It installs the requirements in a temporary venv to see all versions: it needs the internet.

### 8.3 Hadolint: the Dockerfiles

```bat
docker run --rm -i hadolint/hadolint:v2.12.0 < Dockerfile.naive
docker run --rm -i hadolint/hadolint:v2.12.0 < runs\app\plan\Dockerfile
```

*Tested* on X-Ray's Dockerfiles. Three rules come up, and none needs a change:
- `DL3042 Avoid use of cache directory with pip`: a false alarm here. X-Ray's pip lines use
  `--mount=type=cache`, which keeps pip's cache out of the image; Hadolint does not see that
- `DL3008 Pin versions in apt get install`: a choice. A pinned Debian version disappears from Debian's servers
  after a while, and then the build fails. The base image's tag fixes the Debian release anyway
- `DL3059 Multiple consecutive RUN instructions`: information only (X-Ray keeps the steps apart, so that a change
  rebuilds less)

Without them: `docker run --rm -i hadolint/hadolint:v2.12.0 hadolint --ignore DL3042 --ignore DL3008 --ignore DL3059 - < Dockerfile`.
Anything else Hadolint says is worth a look.

---

## 9. The .NET developer

The same pipeline:
- **The Dockerfile**: `dotnet_check.py` and the form of `DOTNET_WALKTHROUGH.html` write it, from the published
  folder. It stays in the dashboard's repository.
- **Linux images from Windows**: images built on Windows with Docker Desktop are Linux images, and they run on the
  Ubuntu server unchanged. Check one:
  `docker image inspect --format "{{.Os}}/{{.Architecture}}" dashboard:1.4.0` must print `linux/amd64` (*tested*
  here on images built on Linux). `windows/amd64` means Docker Desktop was switched to Windows containers when it
  was built.
- **Versions and the registry**: `dashboard:1.4.0-rc1` for the tester, `dashboard:1.4.0` for production, pushed to
  the same registry.
- **Weaknesses**: `dotnet list package --vulnerable` before a release; Trivy on the image (8.1).
- **No IIS**: ASP.NET Core answers with its own server, Kestrel, inside the container. Caddy in front does HTTPS
  (DOTNET_VS_ML.md section 12: what IIS did, and what takes over).

---

## 10. What changed in the tools for this

| Tool | Version | Change |
|---|---|---|
| `xray_release.py` | 0.1.0 | new: one release, every step in a row (section 6) |
| `xray_runfile.py` | 0.2.17 | written again, the run files keep the settings you changed at their top, and run.env keeps your values (`run.env.xray` is X-Ray's own version, to tell them apart). The build files end with the build's exit code, so a failed build stops what follows (before, the next step ran on the image of the build before). On Windows, Notepad stays closed when `XRAY_QUIET=1` (xray_release.py sets it). The values of the project's `.env` go into run.env. It keeps its options in `runs\NAME\runfile.json` |
| `xray_naive.py` | 0.4.14 | `.env` files stay out of the image (`Dockerfile.naive.dockerignore`), and naive-check.txt says so. It keeps its options in naive-check.json. A pip that cannot check its certificate (a proxy's CA file not found) counts as "the package index could not be reached", not as "no Linux wheel" |
| `xray_static.py` | 0.5.22 | keeps its options in the Step 1 map, so a release runs it exactly the same way |
| `xray_plan.py` | 0.1.23 | never copies a `.env` into the slim image (*tested*: before, a test project's `.env` with a password was in it), and `.env.example` lists the other names of the project's `.env`. `compose.yml`: `stop_signal: SIGINT` and `stop_grace_period: 30s` (section 7) |

Before these versions, a project's `.env` went into the images, and a Step 2 run used its values from there. Now
the runs get them from `run.env`: xray_runfile.py copies them there.
