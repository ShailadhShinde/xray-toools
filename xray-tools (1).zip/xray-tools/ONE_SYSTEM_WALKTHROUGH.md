# One System Walkthrough

You have one combined image and three compose files (detector, hub, worker) that you joined with a network you made by hand, plus the dashboard's compose file. This walkthrough turns them into one compose file in one folder. Then you make the copy that clients get, with a database of its own, and then the clients themselves. Every step shows the command, what you should see, and what to do when you see something else.

<form class="fill" id="fill" autocomplete="off">
<p class="fill-head"><strong>Your values</strong> <span>Type them once: every command on this page uses them. They stay in this browser.</span></p>
<label for="f-tools">X-Ray tools folder<input id="f-tools" data-root data-token="D:\xray-tools" value="D:\xray-tools" spellcheck="false"></label>
<label for="f-dash">Dashboard's compose folder<input id="f-dash" data-token="D:\dashboard\docker" value="D:\dashboard\docker" spellcheck="false"></label>
<label for="f-site">New folder for your site<input id="f-site" data-token="D:\suite\site" value="D:\suite\site" spellcheck="false"></label>
<label for="f-host">Hosting folder (clients)<input id="f-host" data-token="D:\hosting" value="D:\hosting" spellcheck="false"></label>
<label for="f-server">Address clients type<input id="f-server" data-token="192.168.1.50" value="192.168.1.50" spellcheck="false"></label>
<label for="f-mysqlbin">MySQL's bin folder on the PC<input id="f-mysqlbin" data-token="C:\Program Files\MySQL\MySQL Server 8.0\bin" value="C:\Program Files\MySQL\MySQL Server 8.0\bin" spellcheck="false"></label>
<label for="f-dbname">Your database's name<input id="f-dbname" data-token="DBNAME" value="suite" spellcheck="false"></label>
<button type="reset">Back to the examples</button>
</form>

*Tested* on Ubuntu 24.04 with Docker 29, end to end: three test programs in one combined image (detector, hub and worker, set up like yours), an ASP.NET dashboard image and MySQL 8.4. The run covered the four separate files, the one file, the master copy with its own database, and two clients. The outputs below come from that run. The folders and the database's name are written as this page's Windows examples. Not tested here: Windows itself and a GPU.

---

## 0. Did the tools already do this?

Partly. Three earlier pieces came close, but none of them takes the files you run today:

| Earlier | What it did | Why it is not enough now |
|---|---|---|
| CLIENT_HOSTING.md, section 1.2 | showed the one file, written by hand | you would copy every setting over yourself |
| SYSTEM_WALKTHROUGH.html, step 3 | a small file that lists your four files (`include`) | each part keeps its own folder and `.env`: the client tool cannot copy that per client |
| `xray_system.py` | a system file from each project's X-Ray map | it builds every project on its own and does not use your combined image |

New in this zip: **`xray_merge.py`**. It reads the compose files you start today and writes the one file, with all their settings. It only reads your files and never changes them, so you can always go back.

## 1. The picture

```text
 NOW                                                    AFTER  (part A, steps 2-8)
 runs\detector\plan\compose.combined.yml  --+              D:\suite\site\
 runs\hub\plan\compose.combined.yml      +-- suite-net    compose.yml   detector + hub + worker + dashboard
 runs\worker\plan\compose.combined.yml  --+  (by hand)     .env          the image versions
 D:\dashboard\docker\compose.yml                          detector.env  hub.env     worker.env  each program's settings
                                                          data\         what the programs write
 4 x "docker compose up", you keep the order            1 x "docker compose up -d --wait": the order is in the file

 THEN  (part B, steps 9-12)                             THEN  (part C, steps 13-18)
 D:\hosting\system\     the master copy for clients:    D:\hosting\clients\client-a\   one copy per client, with its
                        the same + a MySQL (db)         D:\hosting\clients\client-b\   own network, database, passwords
                                                        D:\hosting\proxy\              the one way in
```

| Part | Steps | You get | Your database |
|---|---|---|---|
| A. Your site | 2-8 | one file, one folder, one command | stays where it is: nothing moves |
| B. The master copy | 9-12 | the copy clients get, tested once | a MySQL of its own, empty, with your tables |
| C. Clients | 13-18 | one closed-off copy per client, behind one proxy | each client gets its own |

Do part A now. Do parts B and C when the first client comes.

---

## 2. Check what you have (2 minutes)

First the new tool. It comes with the new `xray-tools.zip`: unzip it over your tools folder (your `runs` folder stays).

```bat
cd /d D:\xray-tools
python xray_merge.py --help
```

You should see:

```text
usage: xray_merge.py [-h] --out OUT [--name NAME] [--rename OLD=NEW]
                     [--db {mysql,postgres}] [--db-port PORT] [--force]
                     files [files ...]
```

`can't open file ... xray_merge.py`: the new zip is not unpacked in this folder yet.

Then the images and what runs now:

```bat
docker image ls --format "{{.Repository}}:{{.Tag}}  {{.Size}}" suite-combined
docker image ls --format "{{.Repository}}:{{.Tag}}  {{.Size}}" dashboard
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Networks}}"
```

You should see (other versions and sizes are fine):

```text
suite-combined:latest  180MB
dashboard:latest  432MB

NAMES                 IMAGE            STATUS          NETWORKS
dashboard-web-1       dashboard        Up 12 seconds   dashboard_default
worker-worker-1       suite-combined   Up 12 seconds   suite-net
hub-hub-1             suite-combined   Up 13 seconds   suite-net
detector-detector-1   suite-combined   Up 13 seconds   suite-net
```

Everything should work the old way before you merge, because a problem in a file stays a problem in the one file. If a program is down, start it the old way first and check it.

The four compose files on this page:

- `D:\xray-tools\runs\detector\plan\compose.combined.yml`, and the same for `hub` and `worker`
- `D:\dashboard\docker\compose.yml`

If your files have other names or folders, use yours in step 3.

## 3. Write the one file (1 minute)

```bat
cd /d D:\xray-tools
python xray_merge.py --name suite --out D:\suite\site ^
  runs\detector\plan\compose.combined.yml runs\hub\plan\compose.combined.yml ^
  runs\worker\plan\compose.combined.yml D:\dashboard\docker\compose.yml ^
  --rename web=dashboard
```

| Part | Means |
|---|---|
| `--name suite` | the project's name: the containers become `suite-detector-1`, `suite-hub-1` ... |
| `--out D:\suite\site` | a new folder for the one file (made if missing). Your old folders stay as they are |
| the four files | every compose file you start today, in any order |
| `--rename web=dashboard` | the dashboard's service is called `web` in its own file, and `dashboard` in the system. Leave it out to keep `web` |

You should see:

```text
xray_merge 0.2.0: 4 compose file(s) -> ONE: D:\suite\site\compose.yml   (project suite)

SERVICES
  detector   suite-combined:${SUITE_COMBINED_VERSION:-latest}   from D:\xray-tools\runs\detector\plan\compose.combined.yml
  hub        suite-combined:${SUITE_COMBINED_VERSION:-latest}   from D:\xray-tools\runs\hub\plan\compose.combined.yml
  worker     suite-combined:${SUITE_COMBINED_VERSION:-latest}   from D:\xray-tools\runs\worker\plan\compose.combined.yml
  dashboard  dashboard:${DASHBOARD_VERSION:-latest}   from D:\dashboard\docker\compose.yml (service web there)

ADDRESSES - a service reaches another by its name and the port INSIDE that container
  worker     HUB_URL: http://host.docker.internal:5014/check  ->  http://hub:5014/check   (worker.env)

OUTSIDE THIS SYSTEM - left as they are (cameras, a database on this PC or elsewhere ...)
  dashboard  ConnectionStrings__Main: host.docker.internal:3306 - a MySQL outside this system (--db mysql: the system's own)
  hub  DB_HOST: host.docker.internal - a database outside this system (--db mysql or --db postgres: the system's own)

START ORDER
  detector: healthy = it accepts a connection on port 5011 (checked every 10 s)
  hub: healthy = it accepts a connection on port 5014 (checked every 10 s)
  hub starts after detector is healthy
  worker starts after hub is healthy

FILES IN D:\suite\site
  compose.yml            the system
  .env                   ConnectionStrings__Main, SUITE_COMBINED_VERSION, DASHBOARD_VERSION
  detector.env           from D:\xray-tools\runs\detector\plan\.env
  hub.env                from D:\xray-tools\runs\hub\plan\.env
  worker.env             from D:\xray-tools\runs\worker\plan\.env
  data/detector-output/  detector writes here - before: D:\xray-tools\runs\detector\plan\output (copy over what you still need)

LEFT OUT
  the network(s) suite-net added to join the files: not needed - every service is on this file's own network (suite_default)
  worker: extra_hosts host.docker.internal - its settings do not use it any more

PORTS - kept: the way in from this PC (the services reach each other without them): detector 5011:5011; hub 5014:5014; dashboard 8090:8080

NOTES
  dashboard: build: left out - build it in its own folder as before (D:\dashboard\docker); this file runs the image dashboard

NEXT
  ...
```

Read it block by block. Your lines will differ: they come from your settings.

| Block | What it tells you |
|---|---|
| ADDRESSES | each setting it changed. An address of another program of the system becomes that program's service name, with the port inside its container. Check each line |
| OUTSIDE THIS SYSTEM | addresses left as they are: your database, cameras, servers elsewhere. Your database stays where it is |
| START ORDER | who waits for whom. A program that others call gets a check (a healthcheck): it counts as healthy once it accepts a connection on its port |
| FILES | what it wrote. detector now writes to `data\detector-output`. The old `output` folder keeps its files: copy over what you still need |
| LEFT OUT | your hand-made network `suite-net`, which one file does not need, and `extra_hosts` lines that nothing uses any more |
| NOTES | this file does not build the dashboard. Build it in its own folder as before; this file then runs the new image |

If you see this instead:

| Message | Do |
|---|---|
| `two files have a service called X` | two files use the same service name. The message names both projects; rename the service in one of them: `--rename PROJECT/X=NEW-NAME` |
| `docker compose cannot read ...` | that file has an error, and the lines after the message say which. In that file's folder, `docker compose -f FILE config` shows it alone |
| `... has a compose.yml already` | you ran it before. Pick another `--out`, or add `--force` to write it again. Changes you made in that folder's compose.yml, .env and NAME.env files are then lost |

## 4. Look at what it wrote (3 minutes)

```bat
dir /a D:\suite\site
notepad D:\suite\site\compose.yml
```

The folder has: `.env`, `detector.env`, `compose.yml`, `data`, `merge.txt` (the report you just saw), `hub.env`, `worker.env`.

Two services of the new `compose.yml`:

```text
  # from D:\xray-tools\runs\hub\plan\compose.combined.yml
  hub:
    image: "suite-combined:${SUITE_COMBINED_VERSION:-latest}"
    command:
      - python
      - main.py
    working_dir: /app/hub
    restart: unless-stopped
    env_file:
      - ./hub.env
    ports:
      - "5014:5014"
    depends_on:
      detector:
        condition: service_healthy
    healthcheck:
      test:
        - CMD
        - python
        - -c
        - "import socket; socket.create_connection(('127.0.0.1', 5014), 3)"
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 30s
    extra_hosts:
      - "host.docker.internal:host-gateway"
    stop_grace_period: 30s
    stop_signal: SIGINT

  # from D:\xray-tools\runs\worker\plan\compose.combined.yml
  worker:
    image: "suite-combined:${SUITE_COMBINED_VERSION:-latest}"
    command:
      - python
      - main.py
    working_dir: /app/worker
    restart: unless-stopped
    env_file:
      - ./worker.env
    depends_on:
      hub:
        condition: service_healthy
    stop_grace_period: 30s
    stop_signal: SIGINT
```

| Line | Means |
|---|---|
| `image: "suite-combined:${SUITE_COMBINED_VERSION:-latest}"` | the version comes from `.env`: one line there for all three programs |
| `env_file: ./hub.env` | its settings, copied from its old `.env` |
| `depends_on ... service_healthy` | start only when that one answers |
| `healthcheck` | the check: can a connection be made to its port? |
| `ports` | as before: the way in from this PC and from other PCs |
| `extra_hosts` | kept for hub: its database is still reached as `host.docker.internal` |

The changed setting, in `worker.env`:

```bat
type D:\suite\site\worker.env
```

```text
# worker's settings - copied by xray_merge.py from D:\xray-tools\runs\worker\plan\.env on 2026-11-23.
# The other services of the system: by their service names. Never commit this file.
# worker's settings
EVERY_SECONDS=5
# xray_merge.py: was http://host.docker.internal:5014/check
HUB_URL=http://hub:5014/check
ROUNDS=0
```

The old value stays as a comment above the new one.

## 5. Stop the four separate ones (1 minute)

The one file uses the same ports (5011, 5014, 8090), so the old containers must go first.

```bat
cd /d D:\xray-tools\runs\detector\plan
docker compose -f compose.combined.yml down
cd /d D:\xray-tools\runs\hub\plan
docker compose -f compose.combined.yml down
cd /d D:\xray-tools\runs\worker\plan
docker compose -f compose.combined.yml down
cd /d D:\dashboard\docker
docker compose down
```

Each one shows:

```text
 Container detector-detector-1 Stopping 
 Container detector-detector-1 Stopped 
 Container detector-detector-1 Removing 
 Container detector-detector-1 Removed 
```

`down` removes the containers. Your images, files and folders stay. To go back at any time before step 7, run `docker compose up -d` in those four folders again, in your old order.

## 6. Start the one file (1 minute)

```bat
cd /d D:\suite\site
docker compose config -q
docker compose up -d --wait
```

`config -q` prints nothing when the file is right. `up -d --wait` starts everything in the right order, and returns once every service runs and answers its check:

```text
 Network suite_default Created
 Container suite-detector-1 Created
 Container suite-dashboard-1 Created
 Container suite-hub-1 Created
 Container suite-worker-1 Created
 Container suite-detector-1 Started
 Container suite-detector-1 Waiting
 Container suite-dashboard-1 Started
 Container suite-detector-1 Healthy
 Container suite-hub-1 Started
 Container suite-hub-1 Waiting
 Container suite-hub-1 Healthy
 Container suite-worker-1 Started
 ...
 Container suite-worker-1 Healthy
 Container suite-hub-1 Healthy
```

In the test this took 12 seconds. Hub started only after detector was healthy, and worker only after hub.

```bat
docker compose ps --format "table {{.Service}}\t{{.Status}}\t{{.Ports}}"
```

```text
SERVICE     STATUS                    PORTS
dashboard   Up 11 seconds             0.0.0.0:8090->8080/tcp
detector    Up 11 seconds (healthy)   0.0.0.0:5011->5011/tcp
hub         Up 6 seconds (healthy)    0.0.0.0:5014->5014/tcp
worker      Up Less than a second     
```

If you see this instead:

| You see | Means, and what to do |
|---|---|
| `Bind for 0.0.0.0:5011 failed: port is already allocated` | an old container still runs. Find it with `docker ps` and remove it with `docker rm -f NAME` |
| `dependency failed to start: container suite-detector-1 is unhealthy` | detector did not accept connections in time. `docker compose logs --tail 30 detector` shows why. When a service has a GPU, its check waits up to 3 minutes for the model to load |
| `network suite-net ... not found` | this is not from the one file: an old compose file was started again |

## 7. Check that they talk (2 minutes)

```bat
docker compose logs --tail 3 worker
```

```text
worker-1  | worker calls hub at http://hub:5014/check every 5 s
worker-1  | worker: hub answered {"result": "TEST5197", "db": "reachable"}
worker-1  | worker: hub answered {"result": "TEST5247", "db": "reachable"}
```

These are the test programs' lines; yours print their own. Look for the lines that show a call worked, and for errors. `docker compose logs --tail 20 hub` and `... detector` show the others.

Then open the dashboard in a browser, as before: `http://localhost:8090`.

When all is well, remove the hand-made network:

```bat
docker network rm suite-net
```

It prints `suite-net`. If it says `has active endpoints`, an old container still uses the network: `docker network inspect suite-net` lists it under "Containers".

## 8. Every day, at your site

Run these in `D:\suite\site`:

| You want | Command |
|---|---|
| what runs | `docker compose ps` |
| the last lines of one program | `docker compose logs --tail 50 hub` (add `-f` to keep following, Ctrl+C to stop) |
| restart one program | `docker compose restart hub` |
| stop all / start all | `docker compose stop` / `docker compose start` |
| a new version of the programs | change `SUITE_COMBINED_VERSION=1.1` in `.env`, then `docker compose up -d --wait`. Only detector, hub and worker restart; the dashboard keeps running |
| a changed setting (`hub.env`, `compose.yml`) | `docker compose up -d --wait`: only what changed restarts |
| everything off, containers removed | `docker compose down`: files and data stay |

A new version, in the test:

```text
 Container suite-dashboard-1 Running
 Container suite-detector-1 Recreate
 Container suite-detector-1 Recreated
 Container suite-hub-1 Recreate
 Container suite-hub-1 Recreated
 Container suite-worker-1 Recreate
 Container suite-worker-1 Recreated
 ...
 Container suite-hub-1 Healthy
```

After a restart of the PC, the containers come back with Docker (`restart: unless-stopped`). Docker then starts them all at once, without the start order. A program that calls another should keep retrying, as worker does.

---

## 9. Why clients need a database of their own

Every client gets a copy of the system. If every copy used your database, all clients would read and write the same tables, and see each other's data. So the master copy gets a MySQL of its own (`--db mysql`): a container named `db`, with its data in a Docker volume. Each client's copy then has its own `db`, with its own data and password.

The new database starts empty. It gets your tables and stored procedures (the structure, without rows) from a file you export once, in step 11.

Your own site can move into a container database too, rows included: DATABASE_WALKTHROUGH.md, part 2 (MySQL) or part 3 (PostgreSQL). That page also explains why rows written from containers may not show in Workbench.

Your site from part A does not change: it keeps your database.

## 10. Write the master copy (1 minute)

The same command as step 3, with `--db mysql`, another folder and no `--name`:

```bat
cd /d D:\xray-tools
python xray_merge.py --db mysql --out D:\hosting\system ^
  runs\detector\plan\compose.combined.yml runs\hub\plan\compose.combined.yml ^
  runs\worker\plan\compose.combined.yml D:\dashboard\docker\compose.yml ^
  --rename web=dashboard
```

You should see these new lines:

```text
SERVICES
  db         mysql:${MYSQL_VERSION:-8.4}   the system's own MySQL (--db mysql)
  ...

ADDRESSES - a service reaches another by its name and the port INSIDE that container
  hub        DB_HOST: host.docker.internal  ->  db   (hub.env)
  worker     HUB_URL: http://host.docker.internal:5014/check  ->  http://hub:5014/check   (worker.env)
  dashboard  ConnectionStrings__Main: Server=host.docker.internal;Port=3306;Database=suite;Uid=app;Pwd=***  ->  Server=db;Port=3306;Database=suite;Uid=app;Pwd=***   (.env ConnectionStrings__Main)
  hub        DB_PASSWORD: hub.env -> compose.yml as ${DB_PASSWORD} (the new database's password)
  dashboard  ConnectionStrings__Main: in compose.yml now (was ${ConnectionStrings__Main} in .env), its password from .env

START ORDER
  ...
  hub starts after db is healthy
  dashboard starts after db is healthy

THE DATABASE (--db mysql)
  db: MySQL 8.4 - database suite, user app (password DB_PASSWORD) and root (password DB_ROOT_PASSWORD), both made new, in .env
  On its first start it runs the .sql files of ./db/init, and holds only what they make: your tables
  (01-schema.sql), and your rows too if the file has them. Your current database is not changed.
  To look into it from this PC (MySQL Workbench): 127.0.0.1, port 3307, user app, its password from .env
  Its clock: TZ=IST-5:30, from the programs' settings
  uses it: hub, dashboard
```

What changed against your site:

- **The address:** every setting that pointed to your database now points to `db` (hub's `DB_HOST`, the dashboard's connection string).
- **The password:** it is written once, in `D:\hosting\system\.env` (`DB_PASSWORD`, new and random). `compose.yml` hands it to each program: hub gets `DB_PASSWORD: "${DB_PASSWORD}"`, the dashboard gets `Pwd=${DB_PASSWORD}` in its connection string. With one password in one place, the client tool can give each client a new one.
- **The name and user:** the database's name (`suite`) and user (`app`) come from your settings.
- **To look into it:** MySQL Workbench on this PC, at 127.0.0.1 port 3307 (DATABASE_WALKTHROUGH.md, step 11). Port 3306 stays your PC's own MySQL.
- **Its clock:** the time zone of your programs' settings (`TZ`), so `NOW()` gives your own time.

Check the line `uses it:`: it must name every program that uses the database. A program missing there has a database setting the tool did not recognise, because its name has no DB, DATABASE or MYSQL in it. Step 19 shows how to point it to `db` yourself.

## 11. Put your tables into db\init (5 minutes)

MySQL runs the `.sql` files of `db\init` once: on the first start of an empty database. Export the structure of the database you use today (tables and stored procedures, no rows). Clients start without your rows.

**In MySQL Workbench,** with your usual connection: Server > Data Export > tick your database > **Dump Structure Only** > tick **Dump Stored Procedures and Functions**, **Dump Events**, **Dump Triggers** > **Export to Self-Contained File**: `D:\hosting\system\db\init\01-schema.sql` > tick **Include Create Schema** > **Start Export**.

**Or with MySQL's own mysqldump, in CMD on the PC where your MySQL runs** (as root, from that PC itself):

```bat
cd /d D:\hosting\system
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe" -u root -p --no-data --routines --triggers --databases DBNAME --result-file=db\init\01-schema.sql
```

- **After `--databases`:** the database's name. The block THE DATABASE says it (database suite).
- **The password:** it asks `Enter password:`. Type root's password and press Enter; nothing shows while you type.
- **The bin folder:** where your MySQL Server is installed (8.0, 8.4 ...).

Both log in as root from the PC itself, which a Windows install allows. From a container, root is usually refused: DATABASE_WALKTHROUGH.md, step 5. That page also shows the export with your rows, for your own site.

Check the file:

```bat
dir db\init
findstr /n "DEFINER CREATE" db\init\01-schema.sql
```

`dir` lists `01-schema.sql` and `README.txt`. `findstr` shows lines like these:

```text
22:CREATE DATABASE /*!32312 IF NOT EXISTS*/ `suite` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
33:CREATE TABLE `results` (
54:CREATE DEFINER=`root`@`localhost` PROCEDURE `add_result`(IN r VARCHAR(20))
```

Each `DEFINER=` names a user. A stored procedure runs as that user, so the user must exist in the new database:

- `` `app`@`%` ``, the user from THE DATABASE block: fine, the new database has it.
- `` `root`@`localhost` ``: fine.
- Any other user: open the file with `notepad db\init\01-schema.sql` and replace it with `` `root`@`localhost` ``.

MySQL skips `README.txt`; its log says so.

## 12. Run the master copy once (5 minutes)

It uses the same ports as your site, so your site stops for these minutes:

```bat
cd /d D:\suite\site
docker compose stop
cd /d D:\hosting\system
docker compose config -q
docker compose up -d --wait
```

```text
 Volume system_dbdata Created
 Network system_default Created
 Container system-db-1 Started
 Container system-detector-1 Started
 Container system-db-1 Waiting
 Container system-detector-1 Healthy
 Container system-db-1 Healthy
 Container system-hub-1 Started
 Container system-dashboard-1 Started
 Container system-hub-1 Healthy
 Container system-worker-1 Started
 ...
```

A new database's first start takes longer: about 20 seconds in the test. MySQL makes the database, runs `01-schema.sql`, then restarts.

```bat
docker compose ps --format "table {{.Service}}\t{{.Status}}"
docker compose logs db | findstr /c:"initdb.d"
```

```text
SERVICE     STATUS
dashboard   Up 6 seconds
db          Up 17 seconds (healthy)
detector    Up 17 seconds (healthy)
hub         Up 6 seconds (healthy)
worker      Up Less than a second

db-1  | ... [Entrypoint]: /usr/local/bin/docker-entrypoint.sh: running /docker-entrypoint-initdb.d/01-schema.sql
db-1  | ... [Entrypoint]: /usr/local/bin/docker-entrypoint.sh: ignoring /docker-entrypoint-initdb.d/README.txt
```

Your tables are there:

```bat
docker compose exec db mysql -uroot -p DBNAME -e "SHOW TABLES"
```

It asks for a password: `DB_ROOT_PASSWORD` from `D:\hosting\system\.env`. Open the file in Notepad, copy the value, and paste it at the prompt (right-click in CMD).

```text
+-----------------+
| Tables_in_suite |
+-----------------+
| results         |
+-----------------+
```

Then look at the programs: `docker compose logs --tail 10 hub` should show no database errors. In the test, worker still printed `hub answered ... "db": "reachable"`, now with the new database.

The test is done. Remove it, including its test database (`-v`), and start your site again:

```bat
docker compose down -v
cd /d D:\suite\site
docker compose start
```

`-v` deletes this test's database volume (`system_dbdata`). The clients do not use it: each one makes its own.

`D:\hosting\system` is now the master copy. You start it again only to test a change; the clients are copies of it.

---

## 13. Before the first client (once)

On the machine that will run the clients (this PC, or a server):

- **The images:** `docker image ls` shows `suite-combined` and `dashboard`. To get them onto another machine, use `docker save` and `docker load`, or the registry (DEV_PIPELINE.md, section 5).
- **Two more images:** `mysql:8.4` and `caddy:2` download the first time (internet needed once).
- **The master copy:** the folder `D:\hosting\system` is there. Copy the whole folder to a server.
- **Windows only:** the ports 8441-8460 must be free, and the firewall must let other PCs in. CLIENT_HOSTING.md, section 2 has both commands.

The proxy (Caddy) is the only way in: one port per client, a password for people, a key for machines. Your site and the clients can run on the same machine. The clients publish no ports; only the proxy does (8441-8460).

## 14. Add the first client (1 minute)

```bat
cd /d D:\hosting
python D:\xray-tools\xray_clients.py add client-a --system system\compose.yml --web dashboard:8080 --api hub:5014 --server 192.168.1.50
```

| Part | Means |
|---|---|
| `client-a` | the client's name: small letters, digits and `-`. It names the client's folder, network, database and containers, and it is the dashboard's user name |
| `--system` | the master copy |
| `--web dashboard:8080` | what people open in a browser: the service's name and its port inside the container (8080, not 8090) |
| `--api hub:5014` | what software outside calls, with a key |
| `--server` | the address the client's people type to reach this machine |

You should see:

```text
client-a: ready to start

  D:\hosting\clients\client-a
    compose.yml   the system's services, closed off: no ports, no container names, its own network
    .env          the system's settings, new secrets: DB_PASSWORD, DB_ROOT_PASSWORD
    data/         its files    ACCESS.txt   what to hand over    client.json   its settings for this tool
  D:\hosting\proxy\sites\client-a.caddy   its way in

  NOTE detector: ./data/detector-output (/xout/output) starts EMPTY - the system's folder has 1 file(s), not copied (they may be your office's data). If the program needs them (templates, settings):  robocopy "D:\hosting\system\data\detector-output" "D:\hosting\clients\client-a\data\detector-output" /E
  NOTE SHARED read-only by every client (models, settings, database first-start scripts): db: D:\hosting\system\db\init -> /docker-entrypoint-initdb.d

  Address:   https://192.168.1.50:8441
  ...
  PEOPLE (browser):
    open      https://192.168.1.50:8441/
    user      client-a
    password  <20 random characters>

  MACHINES (hub): every request with the header     X-API-Key: <the key>
    address   https://192.168.1.50:8441/hub/ + the program's own path     (its /x is https://192.168.1.50:8441/hub/x)
    key       <43 random characters>
```

The first NOTE is about the file detector wrote during step 12's test, and the client does not need it. Before the start, put this client's own values in `D:\hosting\clients\client-a\hub.env` and the other settings files (its cameras, its options). Any password of something outside your system, such as a camera's login, was made random: put the client's real one there. CLIENT_HOSTING.md, section 4 has the details.

## 15. Start it and test it (2 minutes)

```bat
python D:\xray-tools\xray_clients.py start client-a
```

```text
starting client-a (docker compose up -d in D:\hosting\clients\client-a) ...
starting the proxy ...

client-a is running: https://192.168.1.50:8441
Hand over: ACCESS.txt + caddy-root.crt (in D:\hosting\clients\client-a)
Next:  python xray_clients.py test client-a
```

```bat
python D:\xray-tools\xray_clients.py test client-a
```

```text
client-a through the proxy - https://192.168.1.50:8441   (sent to this machine, as a browser would send it)
  OK   hub: no key                -> 401   (want 401)
  OK   hub: a wrong key           -> 401   (want 401)
  OK   hub: its key               -> 404   (want not 401 (the program's own answer))
  OK   dashboard: no password     -> 401   (want 401)
  OK   dashboard: a wrong one     -> 401   (want 401)
  OK   dashboard: its password    -> 200   (want not 401)

all as it should be
```

- **401:** the proxy stopped the request, as it should without the key or the password.
- **404 with the key:** hub itself answered, with "no such page" for `/`. The key works.

From another PC, open `https://192.168.1.50:8441`: it asks for the user name and password. The browser warns about the certificate until `caddy-root.crt` is installed on that PC (CLIENT_HOSTING.md, section 7).

## 16. Hand it over

Give the client two files from `D:\hosting\clients\client-a`:

- **`ACCESS.txt`:** the address, user name, password and key. Hand it over through a password manager, then delete it from the server.
- **`caddy-root.crt`:** the certificate their PCs install once.

CLIENT_HOSTING.md, section 7 has the details.

## 17. The next client, and a check that they are apart

```bat
python D:\xray-tools\xray_clients.py add client-b --system system\compose.yml --web dashboard:8080 --api hub:5014 --server 192.168.1.50
python D:\xray-tools\xray_clients.py start client-b
python D:\xray-tools\xray_clients.py test client-b
python D:\xray-tools\xray_clients.py list
```

client-b gets the next port (8442), its own network, database, data and passwords. The proxy is not restarted, so client-a keeps running:

```text
the proxy joined client-b_net and took client-b's settings - no other client was interrupted
```

`list`:

```text
client         address                            people             machines               running
client-a       https://192.168.1.50:8441          dashboard:8080     /hub/                  5/5
client-b       https://192.168.1.50:8442          dashboard:8080     /hub/                  5/5
```

Everything on the machine (`docker ps --format "table {{.Names}}\t{{.Status}}"`) shows the two clients, the proxy and your site side by side:

```text
NAMES                   STATUS
client-b-worker-1       Up 19 seconds
client-b-hub-1          Up 25 seconds (healthy)
client-b-dashboard-1    Up 25 seconds
client-b-db-1           Up 36 seconds (healthy)
client-b-detector-1     Up 36 seconds (healthy)
clients-proxy-caddy-1   Up 42 seconds
client-a-worker-1       Up 59 seconds
client-a-hub-1          Up About a minute (healthy)
client-a-dashboard-1    Up About a minute
client-a-db-1           Up About a minute (healthy)
client-a-detector-1     Up About a minute (healthy)
suite-worker-1          Up About a minute
suite-hub-1             Up About a minute (healthy)
suite-detector-1        Up About a minute (healthy)
suite-dashboard-1       Up About a minute
```

Check that client-a cannot reach client-b:

```bat
cd /d D:\hosting\clients\client-a
docker compose exec hub python -c "import socket; socket.create_connection(('client-b-hub', 5014), 3)"
```

```text
socket.gaierror: [Errno -2] Name or service not known
```

client-a has never heard of client-b's programs. Its own database it does reach:

```bat
docker compose exec hub python -c "import socket; socket.create_connection(('db', 3306), 3); print('own db: reachable')"
```

```text
own db: reachable
```

In the test, client-a's key at client-b's address got 401 too.

## 18. Every day, with clients

Run these in `D:\hosting`; `...` stands for `python D:\xray-tools\xray_clients.py`.

| You want | Command |
|---|---|
| all clients, and how many containers of each run | `... list` |
| one client's programs | `cd clients\client-a`, then `docker compose ps` or `docker compose logs --tail 50 hub` |
| a client's own setting (its cameras ...) | edit `clients\client-a\hub.env`, then `... start client-a` |
| a new version for one client | `SUITE_COMBINED_VERSION=1.1` in `clients\client-a\.env`, then `... start client-a` |
| a change of the master copy, for one client | `... update client-a`, then `... start client-a` |
| a new password or key | `... password client-a` or `... key client-a` |
| a client leaves | `... remove client-a` (its folder, data and database stay) |

Backups, limits per client and the GPU: CLIENT_HOSTING.md, sections 9-12.

## 19. When something is wrong

| You see | Do |
|---|---|
| a program calls another at a wrong address after the merge | fix it in that program's NAME.env: the other service's name and its port inside. Then `docker compose up -d --wait` |
| a program still calls an IP of the PC (`192.168...:5014`) | at your site this works (the ports are still published), but not for clients, who have no ports. Use the service's name instead: `http://hub:5014/...` |
| a setting inside an image, such as the dashboard's `appsettings.json` | the tool cannot see it. Override it in compose.yml under that service's `environment:`, e.g. `AppSettings__HubUrl: http://hub:5014/check` |
| `Access denied for user` in the master copy's or a client's logs | that program's database password setting has a name the tool did not recognise. In compose.yml, under that service's `environment:`, add `ITS_SETTING: "${DB_PASSWORD}"`. Its database address goes there too: `ITS_HOST_SETTING: db` |
| `The user specified as a definer does not exist` | see step 11 (DEFINER). Fix `01-schema.sql`, then make the database again: in the master copy `docker compose down -v` and step 12. A client that has no data yet: `docker compose down -v` in its folder, then `... start` |
| a client's start ends with `unhealthy` | `cd clients\client-a`, then `docker compose logs --tail 30 SERVICE` |
| anything else with clients | CLIENT_HOSTING.md, section 12 |

`docker compose down -v` deletes the database of the folder you are in. Run it only where the data is a test, never for a client that already has data.

## 20. On Ubuntu

| Windows (this page) | Ubuntu |
|---|---|
| python | `python3` |
| D:\xray-tools, runs\detector\plan | `/home/you/xray-tools`, `runs/detector/plan` |
| cd /d FOLDER | `cd FOLDER` |
| a line that ends in a space and ^ | ends in a space and `\` |
| dir /a, dir, type, notepad | `ls -A`, `ls`, `cat`, `nano` |
| findstr /n "A B" (A or B), findstr /c:"A" | `grep -n -E "A|B"`, `grep "A"` |
| the PC's mysqldump.exe | `mysqldump` (Ubuntu's MySQL package; `sudo mysqldump` when root logs in through the system) |

Type Linux folders (starting with `/`) under Your values at the top, and every command on this page is shown in its Ubuntu form. On Ubuntu, Docker runs without anyone signed in, so the clients keep running after a restart of the machine.
