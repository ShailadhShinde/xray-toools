# Docker, Proxmox and your clients

What Docker does, what Proxmox does, how the two fit together, and what each one means for the clients you deliver to.
In plain words, with the settings and commands where you need them.

*Not tested here:* Proxmox itself (the test machine is not a Proxmox server). The Proxmox steps follow Proxmox's own
documentation; check them against the version you install. The Docker parts (restarts, compose, programs sharing one
GPU, clients kept apart) are the ones the other guides test.

---

## 0. The short answer

- **Docker is how you package and deliver your programs.** X-Ray turns each project into a small, verified image, and
  one `compose.yml` starts the whole system. It runs the same on any Linux machine with a GPU.
- **Proxmox is how a server machine is split up and looked after.** It turns one physical server into several virtual
  machines (VMs), and it backs them up.
- **They are not rivals.** Docker replaces "one VM per program", not Proxmox. The usual setup is both: Proxmox on the
  server, one Ubuntu VM with the GPU, and Docker inside that VM.
- **The client never sees Proxmox.** What they notice is what Docker gives them: a system that installs quickly, comes
  back after a crash or a power cut, and can be updated or rolled back in minutes.
- **Sections 5 to 9** go deeper: what Docker replaces, which one is better for what and why, how your images,
  containers and networks run inside the VM, and how CPU, RAM, GPU and disk are shared and sized.

---

## 1. The three pieces, in plain words

### The client

The company you deliver a solution to. What they care about:
- it runs, all day, every day
- it comes back by itself after a crash or a power cut
- an update does not break it, and if it does, it is fixed quickly
- their data is safe, and kept apart from other clients' data
- someone can tell what is wrong when something is wrong

They do not care how the server is built inside, as long as these hold.

### Docker

Docker runs programs in **containers**, inside one Linux system (a real machine or a VM).

| Word | What it is |
|---|---|
| **image** | a program packed with exactly what it needs: Python, the packages, the model code. Built once, the same everywhere. X-Ray builds these and checks them (`VERDICT: PASS`). |
| **container** | an image running. Each program is its own container. They share the machine's Linux, so they are light and start in seconds. |
| **compose.yml** | one file that says which containers make up the system, how they talk to each other, which folders they use, and that they restart by themselves. `docker compose up -d` starts everything. |
| **folders / volumes** | where the data lives: models, videos, pictures, the database. On the machine, not inside the container. Deleting or replacing a container leaves the data alone. |
| **image tag** | the version of an image (`app-slim:1.4`). Every site that runs `1.4` runs exactly the same thing. |

### Proxmox

Proxmox VE is a free, open-source system you install **on the server itself, instead of Windows or Ubuntu**. You
manage it from a web page (`https://SERVER-ADDRESS:8006`). It runs **virtual machines**: each VM is a complete
computer with its own operating system and a fixed share of the server's CPU, RAM and disk.

What it is good at:
- **backups of whole VMs**, on a schedule, and restoring one in a few clicks
- **snapshots**: "save the VM as it is now", try an update, roll back if it went wrong
- **several operating systems** on one server: an Ubuntu VM next to a Windows VM
- **a web screen** with each VM's CPU, RAM, disk and network
- **starting VMs at boot**, in a set order

---

## 2. How they fit together

With Proxmox (a server you host clients on, or one IT already runs):

```
  the physical server  (CPU, RAM, disks, the RTX 3060)
  └─ Proxmox VE                                   <- installed on the machine; web page on port 8006
     ├─ VM "gpu-apps": Ubuntu 24.04, the GPU passed through to it
     │  └─ Docker
     │     ├─ container: your first ML program    <- the images X-Ray built
     │     ├─ container: your second ML program
     │     ├─ container: the API
     │     ├─ container: the database
     │     └─ container: the proxy (Caddy)        <- the only way in from outside
     └─ VM "dashboard" (optional): Windows, if the .NET dashboard has to stay on IIS
```

Without Proxmox (a machine at the client's site that runs only your system):

```
  the physical machine
  └─ Ubuntu 24.04
     └─ Docker
        └─ the same containers, the same compose.yml
```

Your images and compose files are **the same in both pictures**. Only what sits under Ubuntu changes.

---

## 3. What the client gets, and which piece gives it

| The client needs | Docker gives | Proxmox adds |
|---|---|---|
| a quick install at a new site | install Docker, copy the compose folder, `docker compose up -d` | the VM is ready-made, or restored from a template |
| the same version at every site | the image tag: `1.4` is `1.4` everywhere | - |
| a crashed program comes back | `restart: unless-stopped` starts it again; the other containers keep running | - |
| it all comes back after a power cut | Docker starts at boot, and with it the containers | the VM starts at boot ("Start at boot") |
| a bad update undone quickly | the previous image tag again, in minutes | a snapshot of the whole VM, taken before the update |
| the whole server backed up | the data folders, by hand or a script | a nightly backup of the whole VM, restored in a few clicks |
| several programs on one GPU | yes, every container can use the card | no: a passed-through GPU goes to ONE VM (section 7) |
| clients' data kept apart | its own network, folders and passwords per client (CLIENT_HOSTING.md) | a VM per client, if a contract demands it (needs a GPU per VM) |
| a Windows program on the same server | no, Docker runs Linux programs | yes, a Windows VM |
| moving to new hardware | the compose folder + the data folders on the new machine | restore the VM backup on the new server |

---

## 4. The same situations, three ways

| What happens | VMs only, everything installed by hand | Ubuntu + Docker | Proxmox + one VM with Docker |
|---|---|---|---|
| a new client site | days: Python, CUDA and packages on each machine, hoping they match | about an hour | the same hour, plus making the VM once |
| an update breaks something | fix by hand, or reinstall | previous image tag, minutes | the same, or the VM back to its snapshot |
| a program crashes | down until someone restarts it | restarted by Docker | restarted by Docker |
| the disk dies, or the server is replaced | rebuild everything by hand | new machine, same compose files, restore the data folders | restore last night's VM backup, everything included |
| three programs need the GPU | only if all three sit in one VM | they share it | they share it, inside the GPU VM |
| the dashboard needs Windows | a separate Windows machine | a separate Windows machine | a Windows VM on the same server |
| ten clients on one GPU server | ten VMs, but only one can have the GPU | a container set per client (`xray_clients.py`) | the same, inside the GPU VM |
| "which version runs at that site?" | hard to know | the image tag says | the image tag says |

---

## 5. What Docker replaces, and what it does not

**What Docker replaces:**

| Before, without Docker | With Docker | Why it is better |
|---|---|---|
| one VM (or PC) per program, so programs don't break each other's packages | one container per program, all in one VM or machine | each container brings its own Python and packages, but there is no full operating system per program: less RAM, less disk, one system to update |
| installing Python, CUDA and packages by hand at every site | the image, built once by X-Ray and checked (`VERDICT: PASS`) | exactly the same at every site; no "it works on my PC" |
| a Word file of setup steps | `compose.yml` + `.env` | the file IS the setup: nothing forgotten, nothing done differently |
| a Windows service, Task Scheduler, or someone who starts the program | Docker starts at boot, `restart: unless-stopped` | it comes back by itself |
| fixed IP addresses in the code so programs find each other | container names on a Docker network (`http://api:5000`) | works on any machine; a changed IP breaks nothing (CONNECTIONS_GUIDE.md) |
| copying the program folder over to update it | a new image tag | one command, and the old tag back if it is wrong |
| a separate PC per client to keep them apart | a network, folders, passwords and limits per client (CLIENT_HOSTING.md) | one machine carries many clients |

**What Docker does not replace:**
- **the operating system under it:** Ubuntu still needs its updates, and the NVIDIA driver lives there
- **a backup of the whole machine:** Proxmox does that, or your own copies of the data (section 12)
- **Windows programs** (a .NET dashboard on IIS): they need Windows, so a Windows VM or a Windows PC
- **the strongest wall between clients** who run their own code on the server: that is a VM
- **the hardware:** a dead disk or power supply is still dead. Backups, a second disk (RAID) or a spare machine cover that

---

## 6. Which is better, and why

Each question has its own answer:

| Question | Better | Why |
|---|---|---|
| packaging and delivering your programs | **Docker** | the image is built once, checked, and runs the same everywhere; X-Ray makes it small |
| several programs on one GPU | **Docker** | a passed-through card belongs to one VM; inside it, every container can use the card |
| getting the most out of RAM and CPU | **Docker** | a container takes what it uses; a VM keeps its whole share reserved, even when idle (section 9) |
| starting and restarting | **Docker** | a container starts in seconds; a VM boots a whole operating system |
| updating or undoing one program | **Docker** | change the image tag, `docker compose up -d` |
| backing up and restoring a whole server | **Proxmox** | one backup per VM, restored in a few clicks; Docker alone has nothing like it |
| trying a risky system update | **Proxmox** | a snapshot first, and back in a minute if it goes wrong |
| Windows next to Linux on one server | **Proxmox** | each VM has its own operating system |
| a hard wall between clients (a contract, clients' own code) | **Proxmox** (a VM each) | VMs share nothing but the hardware; containers share the VM's Linux |
| the fewest parts at a small site | **Docker alone** | one operating system, one tool |

**So:** Docker for your programs, always. Proxmox underneath when the server needs whole-machine backups, snapshots or
more than one operating system. That is why the setup for a hosting server is both, and the setup for a single machine
at a client's site is Docker alone.

---

## 7. The GPU rule

This decides most of the design:

- **Proxmox gives a GPU to a VM by passing the whole card through** (PCI passthrough). The card then belongs to that
  one VM. Proxmox itself and every other VM can no longer use it.
- **A consumer card like the RTX 3060 cannot be split between VMs.** Splitting one card (NVIDIA vGPU) works only with
  data-centre cards (A / L series) and NVIDIA's licences.
- **Inside one VM, Docker lets every container use that card.** That is how all your programs share one GPU.

So: one GPU = one GPU VM. Put every program that needs the GPU into that VM, as containers. A second VM with a GPU
needs a second card.

---

## 8. How your programs run inside the VM

### From image to running container

1. **The image is built**, from your project and X-Ray's plan: `bash build-slim.sh`, or `docker compose build` in the
   plan's folder. Docker keeps it inside the VM (in `/var/lib/docker`, which belongs on the data disk). `docker images`
   lists them. To bring an image to another machine without building it there:
   `docker save -o app.tar app-slim:1.4`, copy the file, `docker load -i app.tar`.
2. **`docker compose up -d`** reads `compose.yml` and `.env`, and then:
   - makes the compose file's network, if it is not there yet
   - makes one container per service, from its image
   - mounts the folders: models, videos, the folders the program writes, the database's data
   - gives the GPU to the services that ask for it (`capabilities: [gpu]` in the plan's `compose.yml`)
   - publishes the ports listed under `ports:` on the VM's address
   - starts them, and from then on restarts any that stops (`restart: unless-stopped`)
3. **Inside its container, a program sees:** its own files from the image, the mounted folders at their paths, its
   env vars, the GPU (the driver is installed in the VM; the NVIDIA Container Toolkit lends it to the container), and
   the other containers by their names.
4. **When it stops:** Docker starts it again. Its data is in the mounted folders, so nothing is lost.
   `docker compose down` removes the containers and the network, never the images and never the folders.

### The networks: three levels, each with its own job

```
  a client's software, a browser
        |   https://VM-ADDRESS   (port 443)
  ======|=================  the office network (switch, router, firewall: IT's)
        |
  the server's network card
        |
  [ Proxmox bridge vmbr0 ]          a virtual switch: each VM gets its own address
        |
  VM "gpu-apps" at VM-ADDRESS
        |   port 443, published by Docker
        v
    proxy --> api --> model --> GPU      the Docker network: inside the VM only,
               |                         the containers find each other by name
               +--> db --> its folder on the data disk
```

| Level | Connects | Set up by | Where |
|---|---|---|---|
| the office network | the server with the PCs and the clients | IT | the switch, the router, the firewall |
| the Proxmox bridge (`vmbr0`) | each VM with the office network; each VM gets its own address there | the Proxmox install makes it | Proxmox: the server, System, Network; the VM: Hardware, Network Device |
| the Docker networks | the containers with each other, by name | `docker compose up`, from `compose.yml` | inside the VM only: nothing to set in Proxmox |
| the published ports | the way in from outside: `ports: ["443:443"]` on the proxy | `compose.yml` | the VM's address and that port |

- **Only published ports can be reached from outside the VM.** The database and the models stay inside the Docker
  network, out of reach.
- **From another VM or a PC:** `VM-ADDRESS:PORT`. Container names work only between containers on the same Docker
  network.
- **A fixed address for the VM:** a reservation in the office's DHCP (IT), or a fixed address in Ubuntu (netplan), so
  the clients always find it.
- **A firewall in Proxmox:** each VM can have one. If IT turns it on, allow the published ports to the VM.

---

## 9. How the resources are used

### Two levels of sharing

- **Proxmox divides the server between the VMs.** Mostly fixed: what a VM is given is set aside for it.
- **Docker divides the VM between the containers.** Flexible: each container takes what it needs at that moment, up to
  a limit if you set one.

| Resource | Between VMs (Proxmox) | Between containers in a VM (Docker) |
|---|---|---|
| CPU | cores per VM. All VMs together may be given more cores than the server has; then they take turns | the containers share the VM's cores. Limit one: `cpus: "2"` |
| RAM | a VM with a passed-through card has all its RAM set aside from the start, used or not | each container uses what it needs. Limit one: `memory: 2G`; over the limit, only that container is restarted |
| GPU | the whole card to one VM | every container can use it. Computing takes turns; the card's memory (12 GB on an RTX 3060) adds up, and Docker cannot limit it per container (MULTI_CLIENT_HOSTING.md, section 5) |
| disk | each VM disk has a maximum size; on `local-lvm` (thin) it takes only what is written | images, containers and folders share the VM's disks; images that share a base store it once |
| network | the VMs share the server's network card | the containers share the VM's |

The limits go into the compose file, per service (CLIENT_HOSTING.md, section 11):

```yaml
    deploy:
      resources:
        limits:
          cpus: "2"
          memory: 2G
```

### Why it matters: an example

Example numbers: four programs, each using about 1 GB of RAM most of the time and 3 GB at its busiest.

| | One VM per program | One VM, four containers |
|---|---|---|
| RAM set aside | 4 x 8 GB = 32 GB (each: Ubuntu + the busiest moment + spare), always | one VM of 16 GB; the programs use about 4 GB normally, 12 GB at the busiest |
| operating systems to update | 4 | 1 |
| programs that can use the GPU | 1 | 4 |
| what is left on a 64 GB server | 32 GB | 48 GB: room for a Windows VM, a test VM |

### Sizing the GPU VM

1. **Measure each program** at its busiest, in X-Ray's runs and load tests (`run-load`): `docker stats` for RAM and
   CPU, `nvidia-smi` for GPU memory.
2. **RAM of the VM** = every program at its busiest + the database + about 2 GB for Ubuntu and Docker, then about a
   quarter more as spare.
3. **CPU cores** = what the programs use together when busy, + 2 for builds and the system.
4. **GPU memory** = every model on the card + a few hundred MB per process for CUDA. It must stay under the card's
   memory minus about 1 GB.
5. **Disk** = the images (a GPU image is several GB: `docker system df`) + one new version of each image while the old
   one is still there + the data the programs write per day x the days you keep it.
6. **Limits** in the compose file, so one runaway program cannot starve the others.
7. **Watch the VM's graphs in Proxmox for a week**, then adjust. More RAM or cores: change it in Proxmox, then restart
   the VM.

### Keeping the disk tidy

- `docker system df`: how much the images, containers and volumes take
- after a new version runs well: `docker image rm app-slim:1.2` for versions older than the one before it (keep that
  one, to go back to)
- `docker image prune`: removes leftover images that no tag points to any more
- program logs: a size limit per service (`max-size`, CLIENT_HOSTING.md section 11)

---

## 10. Which setup, when

| Where | Setup | Why |
|---|---|---|
| **a client's site, one machine just for your system** | Ubuntu + Docker, no Proxmox | the simplest: one layer less to install, update and understand. Back up the data folders and the database (section 12). |
| **your own server, hosting several clients** | Proxmox, one GPU VM with Docker, more VMs as needed | whole-VM backups and snapshots before risky changes; room for a Windows VM or a test VM next to it |
| **the client's IT already runs Proxmox or VMware** | ask IT for one Ubuntu VM with the GPU passed through, then Docker in it | IT keeps its own tools; you get the same Linux + Docker as everywhere else |
| **a contract demands a separate machine per client** | a VM per client, each with its own GPU | VMs are the stronger wall between clients; each needs its own card (section 7) |

Whatever the setup, **you build and test the same thing**: X-Ray images and compose files. Nothing in them depends on
whether Proxmox is underneath.

---

## 11. Setting up Proxmox with a GPU VM

Once per server. If IT runs the server, send them this section; the part inside the VM is yours.

**1. In the server's BIOS / UEFI:** turn on virtualization (Intel VT-x / AMD-V) and the IOMMU (Intel VT-d /
AMD-Vi). Without the IOMMU a card cannot be passed through.

**2. Install Proxmox VE** from its ISO onto the server. Then open `https://SERVER-ADDRESS:8006` in a browser and log in
as `root` with the password set during the install.

**3. Turn the IOMMU on in Proxmox** (in the server's shell, from the web page: the server's name, then Shell):

```bash
# Intel CPUs: add intel_iommu=on iommu=pt to the kernel command line (AMD: on by default, add iommu=pt only)
#   - booted with GRUB: edit GRUB_CMDLINE_LINUX_DEFAULT in /etc/default/grub, then:
update-grub
#   - booted with systemd-boot (ZFS on the system disk): edit /etc/kernel/cmdline, then:
proxmox-boot-tool refresh

# the modules that hand the card to a VM
printf '%s\n' vfio vfio_iommu_type1 vfio_pci >> /etc/modules
update-initramfs -u -k all
reboot

# after the restart: the IOMMU is on when this prints lines about it
dmesg | grep -e DMAR -e IOMMU
```

Proxmox's documentation ("PCI(e) Passthrough") has the details for boards that need more.

**4. Create the VM** (the web page: Create VM):

| Setting | Value | Why |
|---|---|---|
| ISO | Ubuntu Server 24.04 LTS | what the Linux guides are written and tested for |
| Machine | q35 | the modern PC type; needed for a PCI-Express card |
| BIOS | OVMF (UEFI), with an EFI disk | what passed-through cards expect |
| CPU type | host | the VM sees the real CPU and all its features |
| Cores | 8 (what the server can spare) | for the programs and the builds |
| Memory | 32 GB, **ballooning off** | a VM with a passed-through card keeps all its RAM reserved |
| Disks | 50 GB for Ubuntu + a separate data disk (e.g. 200 GB) on SSD | the data disk holds Docker and the database; it can grow and be backed up on its own |
| Network | bridge `vmbr0` | the VM gets its own address on the office network |
| Options | **Start at boot: yes**, **QEMU Guest Agent: on** | the VM comes back after a power cut; Proxmox can shut it down cleanly |

**5. Give it the GPU:** the VM, then Hardware, Add, PCI Device, the RTX 3060. Turn on "All Functions" (the card's
sound part goes with it) and "PCI-Express". Leave "Primary GPU" off, so the Proxmox console still shows the VM.

**6. Start the VM and install Ubuntu.** Then, inside the VM:

```bash
sudo apt-get install -y qemu-guest-agent      # lets Proxmox shut the VM down cleanly and see its address
sudo systemctl enable --now qemu-guest-agent
```

Then follow LINUX_WALKTHROUGH.html from step 0: the NVIDIA driver, Docker, the NVIDIA Container Toolkit, the tools,
your projects. `nvidia-smi` in the VM must show the RTX 3060.

---

## 12. Day to day

### After a power cut

The chain that brings everything back, with nobody logged in:
1. the server starts Proxmox
2. Proxmox starts the VM ("Start at boot")
3. Ubuntu starts Docker (`sudo systemctl enable docker`, LINUX_WALKTHROUGH step 1)
4. Docker starts the containers (`restart: unless-stopped` in the plans' `compose.yml`)

Test it once before handing over: restart the whole server, wait, then `docker compose ps` in each compose folder.
Every container must say `Up`.

### Watching it

| Where | Shows | Does not show |
|---|---|---|
| Proxmox web page | each VM's CPU, RAM, disk and network, with graphs over time | the programs inside the VM, the GPU |
| `docker compose ps` (in the VM) | which containers run, which restart over and over | how busy they are |
| `docker stats` | CPU and RAM of every container, live | the GPU |
| `nvidia-smi` (or `watch -n 2 nvidia-smi`) | GPU use, its memory, which programs use it | - |
| `docker compose logs -f` | what the programs print | - |

A web screen for the containers is optional: Portainer (Community Edition) runs as one more container. Keep it on the
office network, behind its login, never open to the internet.

### Backups: two kinds, both needed

1. **The whole VM, every night** (Proxmox: Datacenter, Backup, Add). Mode "snapshot" keeps the VM running. Keep
   several days. Store them on another disk, or on a Proxmox Backup Server, never only on the disk the VM is on.
2. **A dump of the database, every night**, from inside the VM (`mysqldump` in the database container, into a folder
   on the data disk, which the VM backup then includes). A VM backup taken while the database writes is like pulling
   the plug: it usually recovers, a dump always restores cleanly.

Without Proxmox (Ubuntu + Docker on the machine), only the second kind exists, so also copy the data folders and the
compose folders to another disk or machine.

Your compose folders belong in git (without `.env`, which holds the passwords). Then any machine can be rebuilt from
git, the `.env` and the data.

### Updates

- **Your programs:** build the new image with a new tag (`app-slim:1.5`), `docker compose up -d`. Broken: set the old
  tag back, `docker compose up -d` again.
- **Ubuntu, the NVIDIA driver, Docker:** take a Proxmox snapshot of the VM first, then update and check. Fine after a
  few days: delete the snapshot (kept for long, snapshots slow the disk). If Proxmox refuses a snapshot of the running
  VM because of the passed-through card, shut the VM down first and take it then. Snapshots need a storage that supports them: the default
  `local-lvm` (LVM-thin) does, as do ZFS and Ceph.
- **Proxmox itself:** a restart of the server restarts every VM on it. Plan it with the client.

---

## 13. Things often misunderstood

- **"If a VM dies, Proxmox starts it on another server."** Only with a cluster (three servers are recommended) and
  storage they share. With one server: if the server is down, every VM on it is down. And a VM with a passed-through
  card cannot move to another server while it runs; that server needs its own card.
- **"Docker replaces Proxmox", or the other way round.** They do different jobs (section 0). The question is only
  whether a site needs Proxmox's backups and extra VMs.
- **"The Docker networks must be set up in Proxmox too."** No. Proxmox gives the VM one address on the office network
  (the bridge `vmbr0`). The Docker networks, container names and ports live inside the VM, exactly as in the other
  guides. At the Proxmox / office-network level, open only the ports the proxy listens on (usually 80 and 443) to the
  VM.
- **"Proxmox has containers too, so we don't need Docker."** Proxmox's containers (LXC) are small virtual systems,
  managed like VMs. They do not run your X-Ray images or compose files. Docker can run inside one, but a GPU and Docker
  inside LXC need extra settings; a VM is the simpler, better-documented way.
- **"The data is inside the container."** No: in the folders the compose file mounts. A container can be deleted and
  made again without losing anything.
- **"More VMs means more safety."** Each VM needs its own operating system, updates and reserved RAM, and only one of
  them can have the GPU. Separate VMs are worth it when a contract or a different operating system needs them.

---

## 14. To tell a client

> Each of our programs runs in its own container, built and tested once and the same at every site. If one stops, it
> starts again by itself, and the others keep working. After a power cut the whole system comes back without anyone
> logging in. An update can be undone in minutes, and your data stays in folders on the server, apart from every other
> client's. On servers we host, the whole system is also backed up every night and can be restored in one step.

The last sentence is true only with Proxmox (or another backup of the whole machine). Without it, say what you do
instead: the nightly database dump and the copy of the data folders.
